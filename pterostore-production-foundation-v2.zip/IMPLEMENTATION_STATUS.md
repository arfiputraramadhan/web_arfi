# Implementation Status

## Included

- Express layered modular backend.
- Prisma PostgreSQL schema + initial migration + seed.
- Redis session cache/rate limit.
- Argon2id auth, OTP email, password reset, CSRF, CAPTCHA hook, TOTP admin MFA.
- Pterodactyl Application API catalog/user/server operations.
- Pterodactyl Client API power/resources/console/backup download URL.
- Pakasir v2 QRIS create/status/cancel/webhook/sandbox simulation.
- Order state machine with DB version guard.
- Wallet + QRIS topup + wallet checkout.
- Voucher + referral bonus.
- BullMQ provisioning, retries, final failure refund + alert email.
- Expiry/grace suspend-delete cron and H-3/H-1 notifications.
- Basic tickets, notifications, account/session controls.
- Admin summary/sync/users/ban/products/vouchers/nodes/wallet adjustment/CSV order export.
- Neobrutalist responsive public pages and dashboard pages.
- Docker, compose, Nginx, PM2, GitHub Actions, security checklist, diagrams.

## Explicitly not represented as complete

- WhatsApp delivery provider: config hooks exist, but no vendor SDK/provider is bundled because no provider was specified.
- Ticket binary attachment storage: schema has `attachmentUrl`, but object storage/provider wiring is not bundled.
- Full admin CMS/broadcast/staff-per-feature UI: core RBAC and audit primitives exist; the admin HTML is intentionally compact.
- Full PDF reporting suite: invoice PDF is implemented; aggregate PDF reports are not.
- Automated PostgreSQL encrypted backup job: deployment docs require an external backup policy.
- End-to-end browser visual verification could not be completed in this runtime because Chromium headless did not terminate reliably.

## Verification performed here

- JavaScript syntax check passed for shipped browser bundle and PM2 config.
- TypeScript parser/static check produced no TS syntax diagnostics after fixes; full typecheck/test could not be executed because `npm install` repeatedly timed out before dependencies were installed.
- Secret scan found only CI dummy test credentials and `.env.example` templates.

## Pembaruan v2

Lihat `docs/FIXLOG.md` untuk daftar perbaikan dan daftar masalah yang masih terbuka. Verifikasi v2: sintaks TypeScript seluruh proyek diperiksa tanpa error sintaks, dan logika murni (TOTP vs vektor RFC 6238, harga, state machine, verifikasi webhook, validasi spesifikasi, parser boolean) dijalankan dengan harness lokal. Typecheck penuh, vitest asli, dan uji end-to-end dengan Postgres/Redis/Pterodactyl/Pakasir belum dijalankan.
