import { describe, it, expect } from 'vitest';
import { amountMatches, isConfirmedPayment } from '../src/modules/payments/verify.js';

describe('verifikasi pembayaran Pakasir (kode asli)', () => {
  it('nominal harus sama persis dan bilangan bulat', () => {
    expect(amountMatches(1000, 1000)).toBe(true);
    expect(amountMatches(1000, '1000')).toBe(true);
    expect(amountMatches(1000, 900)).toBe(false);
    expect(amountMatches(1000, 1000.5)).toBe(false);
    expect(amountMatches(1000, undefined)).toBe(false);
    expect(amountMatches(1000, 'abc')).toBe(false);
  });
  const ok = { order_id: 'PS1', amount: 1000, status: 'completed' };
  it('menerima hanya status completed dengan order_id dan nominal cocok', () => {
    expect(isConfirmedPayment(ok, 1000, 'PS1')).toBe(true);
  });
  it('menolak pending, canceled, order_id beda, nominal beda, dan data kosong', () => {
    expect(isConfirmedPayment({ ...ok, status: 'pending' }, 1000, 'PS1')).toBe(false);
    expect(isConfirmedPayment({ ...ok, status: 'canceled' }, 1000, 'PS1')).toBe(false);
    expect(isConfirmedPayment({ ...ok, order_id: 'PS2' }, 1000, 'PS1')).toBe(false);
    expect(isConfirmedPayment({ ...ok, amount: 999 }, 1000, 'PS1')).toBe(false);
    expect(isConfirmedPayment(null, 1000, 'PS1')).toBe(false);
    expect(isConfirmedPayment(undefined, 1000, 'PS1')).toBe(false);
  });
});
