import { describe, it, expect } from 'vitest';
import { transitions, canTransition } from '../src/modules/orders/transitions.js';

describe('order state machine (kode asli)', () => {
  it('menolak lompatan status', () => {
    expect(canTransition('PENDING', 'ACTIVE')).toBe(false);
    expect(canTransition('PENDING', 'PROVISIONING')).toBe(false);
    expect(canTransition('PAID', 'ACTIVE')).toBe(false);
  });
  it('mengizinkan alur normal', () => {
    for (const [a, b] of [['PENDING', 'PAID'], ['PAID', 'PROVISIONING'], ['PROVISIONING', 'ACTIVE'], ['ACTIVE', 'SUSPENDED'], ['SUSPENDED', 'DELETED']]) {
      expect(canTransition(a, b)).toBe(true);
    }
  });
  it('status akhir tidak bisa keluar', () => {
    for (const s of ['CANCELLED', 'EXPIRED', 'FAILED', 'DELETED']) expect(transitions[s as keyof typeof transitions]).toEqual([]);
    expect(canTransition('DELETED', 'ACTIVE')).toBe(false);
  });
  it('semua tujuan transisi adalah status yang terdefinisi', () => {
    const known = Object.keys(transitions);
    for (const targets of Object.values(transitions)) for (const t of targets) expect(known).toContain(t);
  });
  it('status tak dikenal ditolak', () => {
    expect(canTransition('NGAWUR', 'PAID')).toBe(false);
  });
});
