import { describe, it, expect } from 'vitest';
import { z } from 'zod';
import { parseBool, envBool } from '../src/config/envHelpers.js';

describe('parser boolean env (pengganti z.coerce.boolean)', () => {
  it('string "false" benar-benar false (bug lama: jadi true)', () => {
    for (const v of ['false', 'FALSE', ' False ', '0', 'no', 'off']) expect(parseBool(v)).toBe(false);
  });
  it('nilai true dikenali', () => {
    for (const v of ['true', 'TRUE', '1', 'yes', 'on']) expect(parseBool(v)).toBe(true);
  });
  it('nilai tak dikenal -> undefined', () => {
    expect(parseBool('banana')).toBeUndefined();
    expect(parseBool(undefined)).toBeUndefined();
  });
  it('skema zod: default, "false", "true", dan nilai ngawur', () => {
    const schema = z.object({ A: envBool(false), B: envBool(true) });
    expect(schema.parse({})).toEqual({ A: false, B: true });
    expect(schema.parse({ A: 'false', B: 'false' })).toEqual({ A: false, B: false });
    expect(schema.parse({ A: 'true' }).A).toBe(true);
    expect(() => schema.parse({ A: 'banana' })).toThrow();
  });
});
