import { describe, it, expect } from 'vitest';
import { calcProductPrice, applyDiscount } from '../src/utils/money.js';

const base = { basePrice: 10000, ramPricePerGb: 2500, cpuPricePerCore: 1000, diskPricePerGb: 250, ramMb: 2048, cpuPercent: 100, diskGb: 10, nodeMultiplierBps: 10000, eggMultiplierBps: 10000 };

describe('pricing', () => {
  it('menjumlahkan dasar + RAM + CPU + disk', () => {
    // 10000 dasar + 2 GB x 2500 + 1 core x 1000 + 10 GB x 250 = 18500
    expect(calcProductPrice(base, 1)).toBe(18500);
  });
  it('mengalikan pengali node dan egg (basis poin)', () => {
    expect(calcProductPrice({ ...base, nodeMultiplierBps: 12000 }, 1)).toBe(22200);
    expect(calcProductPrice({ ...base, nodeMultiplierBps: 12000, eggMultiplierBps: 5000 }, 1)).toBe(11100);
  });
  it('dikali jumlah bulan', () => {
    expect(calcProductPrice(base, 3)).toBe(55500);
  });
  it('diskon tidak pernah melebihi subtotal', () => {
    expect(applyDiscount(10000, { percentOff: 50, fixedOff: 20000 })).toBe(10000);
    expect(applyDiscount(10000, { percentOff: 10, fixedOff: 0 })).toBe(1000);
    expect(applyDiscount(10000, undefined)).toBe(0);
  });
});
