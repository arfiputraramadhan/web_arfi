import { describe, it, expect } from 'vitest';
import { parseServerSpec, parseRenewMonths, remainingDays, prorate } from '../src/modules/servers/spec.js';

describe('validasi spesifikasi upgrade', () => {
  const ok = { ramMb: 2048, cpuPercent: 100, diskGb: 10 };
  it('menerima spesifikasi wajar (angka maupun string numerik)', () => {
    expect(parseServerSpec(ok)).toEqual(ok);
    expect(parseServerSpec({ ramMb: '4096', cpuPercent: '200', diskGb: '20' })).toEqual({ ramMb: 4096, cpuPercent: 200, diskGb: 20 });
  });
  it('REGRESI: RAM negatif (eksploit pencetak saldo) ditolak sebelum menyentuh harga', () => {
    expect(() => parseServerSpec({ ...ok, ramMb: -100000000 })).toThrow();
    expect(() => parseServerSpec({ ...ok, cpuPercent: -1 })).toThrow();
    expect(() => parseServerSpec({ ...ok, diskGb: -500 })).toThrow();
  });
  it('menolak NaN, kosong, desimal, tak ada, dan melebihi batas', () => {
    expect(() => parseServerSpec({ ...ok, ramMb: NaN })).toThrow();
    expect(() => parseServerSpec({ ...ok, ramMb: '' })).toThrow();
    expect(() => parseServerSpec({ ...ok, ramMb: 2048.5 })).toThrow();
    expect(() => parseServerSpec({ ramMb: 2048 })).toThrow();
    expect(() => parseServerSpec(undefined)).toThrow();
    expect(() => parseServerSpec({ ...ok, ramMb: 999999999 })).toThrow();
    expect(() => parseServerSpec({ ...ok, ramMb: 0 })).toThrow();
  });
  it('batas bawah dan atas inklusif', () => {
    expect(parseServerSpec({ ramMb: 512, cpuPercent: 10, diskGb: 1 })).toEqual({ ramMb: 512, cpuPercent: 10, diskGb: 1 });
    expect(parseServerSpec({ ramMb: 32768, cpuPercent: 800, diskGb: 500 })).toEqual({ ramMb: 32768, cpuPercent: 800, diskGb: 500 });
  });
  it('periode perpanjangan hanya 1, 2, atau 3 bulan', () => {
    expect(parseRenewMonths(1)).toBe(1);
    expect(parseRenewMonths('3')).toBe(3);
    for (const bad of [0, 4, -1, 1.5, NaN, undefined, null, 'x']) expect(() => parseRenewMonths(bad)).toThrow();
  });
  it('sisa hari minimal 1 dan prorata sesuai arah selisih', () => {
    const now = new Date('2026-10-08T00:00:00Z');
    expect(remainingDays(new Date('2026-10-08T00:00:00Z'), now)).toBe(1);
    expect(remainingDays(new Date('2026-10-18T00:00:00Z'), now)).toBe(10);
    expect(prorate(3000, 15)).toBe(1500);
    expect(prorate(-3000, 15)).toBe(-1500);
    expect(prorate(0, 30)).toBe(0);
  });
});
