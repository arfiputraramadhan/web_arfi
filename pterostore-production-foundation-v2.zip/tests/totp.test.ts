import { describe, it, expect } from 'vitest';
import { base32Encode, base32Decode, generateSecret, totpAt, verifyTotp, keyUri } from '../src/utils/totp.js';

// Vektor uji RFC 6238 Appendix B (SHA-1, secret ASCII "12345678901234567890"), diambil 6 digit terakhir.
const SECRET = base32Encode(Buffer.from('12345678901234567890'));

describe('TOTP RFC 6238', () => {
  it('base32 round trip', () => {
    expect(SECRET).toBe('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ');
    expect(base32Decode(SECRET).toString()).toBe('12345678901234567890');
    const s = generateSecret();
    expect(s.length).toBe(32);
    expect(base32Encode(base32Decode(s))).toBe(s);
  });
  it('cocok dengan vektor resmi', () => {
    const v: Array<[number, string]> = [[59, '287082'], [1111111109, '081804'], [1111111111, '050471'], [1234567890, '005924'], [2000000000, '279037'], [20000000000, '353130']];
    for (const [sec, code] of v) expect(totpAt(SECRET, sec * 1000)).toBe(code);
  });
  it('verifikasi: toleransi 1 langkah, selebihnya ditolak', () => {
    const now = 1234567890 * 1000;
    expect(verifyTotp(SECRET, '005924', { nowMs: now })).toBe(Math.floor(1234567890 / 30));
    expect(verifyTotp(SECRET, '005924', { nowMs: now + 30_000 })).not.toBeNull();
    expect(verifyTotp(SECRET, '005924', { nowMs: now + 90_000 })).toBeNull();
  });
  it('format kode salah ditolak', () => {
    const now = 1234567890 * 1000;
    expect(verifyTotp(SECRET, '12345', { nowMs: now })).toBeNull();
    expect(verifyTotp(SECRET, 'abcdef', { nowMs: now })).toBeNull();
    expect(verifyTotp(SECRET, '', { nowMs: now })).toBeNull();
    expect(verifyTotp('!!bukan-base32', '005924', { nowMs: now })).toBeNull();
  });
  it('otpauth URI memuat issuer dan secret', () => {
    expect(keyUri('budi', 'PteroStore', SECRET).startsWith('otpauth://totp/PteroStore:budi?secret=')).toBe(true);
  });
});
