# PteroStore — Pterodactyl Store Panel

PteroStore adalah fondasi web store Pterodactyl berbasis Node.js + Express + Prisma + PostgreSQL + Redis + BullMQ dengan UI neobrutalist mobile-first.

## Status implementasi

Paket ini adalah **production-oriented foundation** yang sudah runnable secara kode untuk modul inti: autentikasi OTP/reset/session+CSRF/Argon2id, katalog Pterodactyl v2, checkout QRIS Pakasir v2, wallet/top-up, state machine order, idempotent webhook, provisioning queue, retry + refund akhir, expiry/suspend/delete, voucher, referral, server resource/power/reinstall/renew/upgrade, backup download URL, tiket dasar, notifikasi dashboard/email, admin RBAC + MFA, audit dasar, Docker, Nginx, PM2, CI dan test suite.

Beberapa fitur operasional yang sangat spesifik vendor/provider masih sengaja tidak dipalsukan sebagai “selesai”, terutama pengiriman WhatsApp, attachment tiket storage object, broadcast multi-channel lengkap, impersonation UI, laporan PDF non-invoice, dan editor konten admin penuh. Endpoint/data model dapat diperluas tanpa merombak core architecture.

## Arsitektur

```mermaid
flowchart LR
  B[Browser] --> N[Nginx]
  N --> A[Express API]
  A --> P[(PostgreSQL)]
  A --> R[(Redis)]
  A --> PK[Pakasir v2]
  A --> PT[Pterodactyl Application API]
  A --> PC[Pterodactyl Client API]
  A --> Q[BullMQ]
  Q --> W[Worker]
  W --> PT
  W --> M[SMTP]
  C[node-cron] --> A
```

### Alur checkout

```mermaid
sequenceDiagram
  participant U as User
  participant API as Express API
  participant DB as PostgreSQL
  participant PK as Pakasir v2
  participant Q as BullMQ
  participant PT as Pterodactyl

  U->>API: POST /api/orders
  API->>DB: quote + order PENDING
  API->>PK: create-transaction
  PK-->>API: txn_id + qr_string + expired_at
  API->>DB: simpan payment data
  API-->>U: QRIS + payment link
  PK->>API: webhook X-Secret
  API->>PK: transaction-status recheck
  API->>DB: PENDING -> PAID -> PROVISIONING
  API->>Q: enqueue provision job
  Q->>PT: create user/server
  PT-->>Q: server active
  Q->>DB: PROVISIONING -> ACTIVE
```

### Alur autentikasi

```mermaid
sequenceDiagram
  participant U as User
  participant A as API
  participant D as DB
  participant S as SMTP

  U->>A: register
  A->>D: OTP hash + temporary registration
  A->>S: OTP 6 digit
  U->>A: verify OTP
  A->>D: create user + verified timestamps
  A-->>U: session cookie + redirect dashboard
```

## Struktur folder

```text
pterostore/
├── .env.example
├── Dockerfile
├── docker-compose.yml
├── ecosystem.config.cjs
├── deploy/nginx.conf
├── package.json
├── prisma/
│   ├── schema.prisma
│   ├── seed.ts
│   └── migrations/20261008_init/migration.sql
├── src/
│   ├── app.ts
│   ├── server.ts
│   ├── worker.ts
│   ├── config/
│   ├── lib/
│   ├── middleware/
│   ├── modules/
│   │   ├── auth/
│   │   ├── payments/
│   │   ├── pterodactyl/
│   │   ├── orders/
│   │   ├── servers/
│   │   ├── wallet/
│   │   ├── admin/
│   │   ├── account/
│   │   ├── tickets/
│   │   ├── notifications/
│   │   └── content/
│   ├── cron/
│   ├── workers/
│   └── utils/
├── public/
│   ├── *.html
│   └── assets/
├── tests/
└── .github/workflows/ci.yml
```

## Stack dan keputusan teknis

- Node.js 22.12+.
- Express 5.
- Prisma + PostgreSQL sebagai target database produksi pada paket ini.
- Redis untuk session cache, rate limiting, queue backend.
- BullMQ untuk provisioning/reconciliation.
- node-cron untuk housekeeping dan lifecycle.
- Argon2id untuk password dan OTP hashes.
- AES-256-GCM untuk Pterodactyl Client API key dan credential panel yang tersimpan.
- Pino untuk structured logging dengan redaction.
- Zod untuk validation boundary.
- HTML/CSS/JS vanilla untuk frontend agar ringan dan tidak bergantung UI framework besar.

## UI neobrutalism

Satu sumber design token berada di `public/assets/styles.css`: warna solid, border hitam 4px, hard shadow tanpa blur, radius kecil, tombol/card press-state, badge status, form/table/modal-ready primitives, dark mode, dan responsive layout.

Breakpoint diuji secara struktur CSS untuk 320, 375, 640, 768, 900, 1024 dan layout desktop 1440px. Tabel panjang memakai wrapper overflow horizontal sendiri sehingga halaman tidak dipaksa scroll horizontal.

## Setup lokal

1. Salin `.env.example` menjadi `.env` dan isi secret.
2. Pastikan PostgreSQL dan Redis tersedia.
3. Jalankan:

```bash
npm install
npx prisma generate
npx prisma migrate deploy
npm run build
node dist/prisma/seed.js
npm run start
```

Worker:

```bash
npm run worker
```

Development:

```bash
npm run dev
npm run dev:worker
```

## Docker

```bash
cp .env.example .env
# isi .env

docker compose build
docker compose run --rm app npx prisma migrate deploy
docker compose run --rm app node dist/prisma/seed.js
docker compose up -d
```

Nginx berada di container `nginx`. Untuk HTTPS, terminasi TLS disarankan di reverse proxy/load balancer di depan stack atau ganti `deploy/nginx.conf` dengan konfigurasi sertifikat produksi.

## PM2 bare metal

```bash
npm install
npx prisma generate
npx prisma migrate deploy
npm run build
node dist/prisma/seed.js
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
```

## Admin seed

`prisma/seed.ts` membuat akun owner dari `ADMIN_SEED_EMAIL` dan `ADMIN_SEED_PASSWORD`. Ganti password seed sebelum deployment publik dan aktifkan 2FA admin setelah login.

## Pakasir v2

Konfigurasi hanya di environment:

- `PAKASIR_SLUG`
- `PAKASIR_API_KEY`
- `PAKASIR_WEBHOOK_SECRET`
- `PAKASIR_WEBHOOK_PATH_SECRET`
- `PAKASIR_PAYMENT_METHOD=qris`

Alur implementasi:

1. `POST /api/v2/create-transaction/{slug}/{order_id}`.
2. Simpan `txn_id`, `total_payment`, `qr_string`, `payment_link`, `expired_at`.
3. Webhook menerima `X-Secret` + secret acak pada path.
4. Sistem mencocokkan `order_id` dan `amount` dengan DB.
5. Sistem melakukan re-check `transaction-status` ke Pakasir.
6. Hanya status remote `completed` yang boleh menandai order lunas.
7. Provisioning dijalankan BullMQ dan memakai `jobId=provision:{orderId}`.
8. Cron reconciliation memeriksa order PENDING berkala.

Endpoint sandbox `paymentsimulation` hanya dapat dipakai ketika `PAKASIR_ENABLE_SIMULATION=true` dan `NODE_ENV != production`.

## Pterodactyl

Paket menggunakan Application API untuk sinkronisasi tags/eggs/nodes, user, server, suspend/unsuspend, reinstall, build, startup, dan allocation. Untuk start/stop/restart, resource metrics, websocket console, dan backup download URL, paket memakai Client API key milik user yang disimpan terenkripsi.

Pada Pterodactyl 2.x, konsep **Nest** berubah menjadi **Tag**, sehingga model DB `NestTag` menyimpan metadata tag agar katalog tetap konsisten dengan API terbaru.

## Security checklist

- [x] Argon2id password.
- [x] OTP/reset token di-hash.
- [x] Cookie session httpOnly + Secure di production.
- [x] CSRF token terpisah.
- [x] Rate limiting Redis.
- [x] Helmet + CSP.
- [x] CORS strict origin.
- [x] Zod validation.
- [x] Body limit.
- [x] Ownership checks pada server/order/wallet/top-up.
- [x] Harga dihitung server-side.
- [x] Atomic wallet debits dengan row lock.
- [x] Order state machine dengan version guard.
- [x] Pakasir webhook re-check + idempotence.
- [x] Secret tidak dikirim ke frontend.
- [x] Admin MFA gate.
- [x] Structured logs + secret redaction.
- [x] CI lint/test/audit.

Lihat `docs/SECURITY_CHECKLIST.md` untuk checklist OWASP yang dapat diuji manual.

## Test

```bash
npm run lint
npm test
npm audit --audit-level=high
```

Test inti:

- deterministic pricing + voucher cap
- invalid order state jump
- webhook order id/amount validation

CI menyalakan PostgreSQL + Redis service dan menjalankan migration, lint, test, audit.

## API utama

Auth:

- `POST /api/auth/register`
- `POST /api/auth/register/verify`
- `POST /api/auth/register/resend`
- `POST /api/auth/login`
- `POST /api/auth/password/request`
- `POST /api/auth/password/reset`
- `GET /api/auth/me`
- `POST /api/auth/logout`
- `POST /api/auth/logout-all`

Store:

- `GET /api/orders/products`
- `POST /api/orders/quote`
- `POST /api/orders`
- `GET /api/orders`
- `GET /api/orders/:id`
- `GET /api/orders/:id/pdf`

Pakasir:

- `POST /api/payments/webhook/:secret`
- `GET /api/payments/:id/status`
- `POST /api/payments/:id/cancel`
- `POST /api/payments/:id/simulate`

Servers:

- `GET /api/servers`
- `POST /api/servers/client-key`
- `POST /api/servers/:id/power`
- `GET /api/servers/:id/resources`
- `GET /api/servers/:id/console`
- `GET /api/servers/:id/backups`
- `GET /api/servers/:id/backups/:backupId/download`
- `POST /api/servers/:id/reinstall`
- `POST /api/servers/:id/renew`
- `POST /api/servers/:id/upgrade`

Wallet:

- `GET /api/wallet`
- `GET /api/wallet/history`
- `POST /api/wallet/topup`
- `GET /api/wallet/topup/:id/status`

Admin:

- `GET /api/admin/summary`
- `GET /api/admin/users`
- `GET /api/admin/orders/export.csv`
- `GET /api/admin/products`
- `POST /api/admin/products`
- `GET /api/admin/nodes`
- `POST /api/admin/nodes/:id/toggle`
- `POST /api/admin/sync`
- `POST /api/admin/users/:id/ban`
- `POST /api/admin/wallet/adjust`

## Lifecycle

```text
PENDING -> PAID -> PROVISIONING -> ACTIVE -> EXPIRING -> SUSPENDED -> DELETED
                      |                    |
                      v                    v
                    FAILED               ACTIVE
PENDING -> CANCELLED / EXPIRED
```

Order state transitions selalu dicatat di `OrderStateTransition`. Provisioning tidak diproses langsung dari webhook request; webhook hanya memvalidasi pembayaran dan memasukkan job ke queue.

## Cron

- setiap 5 menit: expire pending order, cleanup OTP/reset/temp registration.
- setiap 5 menit: suspend server expired.
- setiap 15 menit: delete setelah grace period.
- setiap jam: sync katalog + reminder H-3/H-1 + auto-renew.
- setiap 2 menit: rekonsiliasi Pakasir pending.

## Catatan produksi

Backup PostgreSQL dan volume Redis harus diperlakukan sebagai bagian dari platform backup, bukan disimpan di repository. Gunakan secret manager, TLS di edge, database credentials terpisah, Redis password/TLS jika lintas host, monitoring uptime, rotasi API key, dan log retention.
