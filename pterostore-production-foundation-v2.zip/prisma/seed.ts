import 'dotenv/config';
import argon2 from 'argon2';
import { PrismaClient, Role } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const password = process.env.ADMIN_SEED_PASSWORD ?? 'ReplaceThisWithStrongPassword123!';
  const email = process.env.ADMIN_SEED_EMAIL ?? 'admin@example.com';
  const passwordHash = await argon2.hash(password, { type: argon2.argon2id });
  await prisma.user.upsert({
    where: { email },
    update: {},
    create: {
      username: 'owner', email, phone: '6280000000000', passwordHash,
      role: Role.OWNER, emailVerifiedAt: new Date(), phoneVerifiedAt: new Date()
    }
  });
  for (const page of [
    ['landing', 'PteroStore', '<h1>PteroStore</h1><p>Hosting panel Pterodactyl dengan provisioning otomatis, pembayaran QRIS, dan operasi terkontrol.</p>'],
    ['faq', 'FAQ', '<h2>FAQ</h2><p>Server dibuat otomatis setelah pembayaran terverifikasi.</p>'],
    ['terms', 'Syarat Layanan', '<h2>Syarat Layanan</h2><p>Gunakan layanan secara sah dan patuhi kebijakan penggunaan panel.</p>'],
    ['status', 'Status Layanan', '<h2>Status Layanan</h2><p>Komponen utama dimonitor oleh worker dan health checks.</p>']
  ] as const) {
    await prisma.contentPage.upsert({ where: { slug: page[0] }, update: { title: page[1], bodyHtml: page[2] }, create: { slug: page[0], title: page[1], bodyHtml: page[2] } });
  }
  if (!(await prisma.product.count())) {
    const tag = await prisma.nestTag.create({ data: { pteroId: 1, name: 'Minecraft', slug: 'minecraft', enabled: true } });
    const egg = await prisma.productEgg.create({ data: { pteroId: 1, nestTagId: tag.id, name: 'Vanilla Java', slug: 'minecraft-java', enabled: true, multiplierBps: 10000 } });
    await prisma.product.create({ data: { name: 'Starter 2GB', slug: 'starter-2gb', description: 'Paket pemula', eggId: egg.id, basePrice: 15000, ramPricePerGb: 2500, cpuPricePerCore: 1000, diskPricePerGb: 250, ramMb: 2048, cpuPercent: 100, diskGb: 10 } });
  }
}
main().finally(() => prisma.$disconnect());
