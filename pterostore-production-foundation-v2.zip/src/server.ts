import app from './app.js';import {env} from './config/env.js';import {prisma} from './lib/prisma.js';import {redis} from './lib/redis.js';import {startCron} from './cron/scheduler.js';
startCron();const server=app.listen(env.PORT,()=>console.log(`PteroStore listening on ${env.PORT}`));
async function shutdown(){server.close();await prisma.$disconnect();await redis.quit();process.exit(0)}process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
