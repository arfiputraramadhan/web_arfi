import 'dotenv/config';
import { z } from 'zod';
import { envBool } from './envHelpers.js';

const schema = z.object({
  NODE_ENV: z.enum(['development','test','production']).default('development'),
  PORT: z.coerce.number().int().positive().default(3000),
  APP_ORIGIN: z.string().url(),
  TRUST_PROXY: z.coerce.number().int().min(0).default(1),
  SESSION_COOKIE: z.string().default('pterostore_session'),
  CSRF_COOKIE: z.string().default('pterostore_csrf'),
  SESSION_TTL_SEC: z.coerce.number().int().positive().default(604800),
  REDIS_URL: z.string().min(1),
  DATABASE_URL: z.string().min(1),
  PTERODACTYL_URL: z.string().url(),
  PTERODACTYL_APPLICATION_API_KEY: z.string().min(10),
  PTERODACTYL_CLIENT_API_BASE: z.string().default('/api/client'),
  PAKASIR_BASE_URL: z.string().url().default('https://app.pakasir.com'),
  PAKASIR_SLUG: z.string().min(1),
  PAKASIR_API_KEY: z.string().min(10),
  PAKASIR_WEBHOOK_SECRET: z.string().min(16),
  PAKASIR_WEBHOOK_PATH_SECRET: z.string().min(16),
  PAKASIR_ENABLE_SIMULATION: envBool(false),
  PAKASIR_PAYMENT_METHOD: z.string().default('qris'),
  SMTP_HOST: z.string().min(1),
  SMTP_PORT: z.coerce.number().int().positive().default(587),
  SMTP_SECURE: envBool(false),
  SMTP_USER: z.string().min(1),
  SMTP_PASS: z.string().min(1),
  SMTP_FROM: z.string().min(1),
  TURNSTILE_ENABLED: envBool(false),
  TURNSTILE_SITE_KEY: z.string().optional(),
  TURNSTILE_SECRET_KEY: z.string().optional(),
  ADMIN_DISCORD_WEBHOOK_URL: z.string().url().optional(),
  ADMIN_ALERT_WEBHOOK_URL: z.string().url().optional(),
  ADMIN_ALERT_EMAIL: z.string().email().optional(),
  APP_ENCRYPTION_KEY: z.string().min(32),
  SESSION_HASH_PEPPER: z.string().min(16),
  CRYPTO_PEPPER: z.string().min(16),
  LOG_LEVEL: z.string().default('info'),
  MAINTENANCE_MODE: envBool(false),
  GRACE_PERIOD_DAYS: z.coerce.number().int().min(0).default(7),
  OTP_COOLDOWN_SEC: z.coerce.number().int().positive().default(60),
  OTP_TTL_SEC: z.coerce.number().int().positive().default(300),
  RESET_TTL_SEC: z.coerce.number().int().positive().default(900)
});
// Variabel kosong (misal "ADMIN_DISCORD_WEBHOOK_URL=") dianggap tidak diisi, bukan string kosong.
const raw = Object.fromEntries(Object.entries(process.env).filter(([, v]) => v !== undefined && v !== ''));
export const env = schema.parse(raw);
