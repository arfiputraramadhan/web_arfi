import { z } from 'zod';

const TRUE_VALUES = ['true', '1', 'yes', 'on'];
const FALSE_VALUES = ['false', '0', 'no', 'off'];

/** Mengembalikan boolean untuk nilai yang dikenali, atau undefined bila tidak dikenali. */
export function parseBool(value: unknown): boolean | undefined {
  if (typeof value === 'boolean') return value;
  if (typeof value !== 'string') return undefined;
  const v = value.trim().toLowerCase();
  if (TRUE_VALUES.includes(v)) return true;
  if (FALSE_VALUES.includes(v)) return false;
  return undefined;
}

/**
 * Pengganti z.coerce.boolean(). Pada coerce.boolean() string "false" menjadi true
 * (karena Boolean("false") === true). Di sini "false", "0", "no", "off" benar-benar false.
 * Nilai tak dikenal sengaja dibiarkan lolos ke z.boolean() agar startup gagal dengan pesan jelas.
 */
export const envBool = (defaultValue: boolean) =>
  z.preprocess((v) => (v === undefined || v === '' ? defaultValue : (parseBool(v) ?? v)), z.boolean());
