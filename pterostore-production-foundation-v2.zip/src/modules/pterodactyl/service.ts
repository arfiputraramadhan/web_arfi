import { env } from '../../config/env.js';
import { fetchJson } from '../../utils/http.js';

type PteroList<T>={data:Array<{attributes:T}>};
class PterodactylService {
  private headers(extra:Record<string,string>={}){return {'Content-Type':'application/json',Authorization:`Bearer ${env.PTERODACTYL_APPLICATION_API_KEY}`,...extra};}
  async listTags(){const j=await fetchJson<PteroList<any>>(`${env.PTERODACTYL_URL}/api/application/tags?per_page=100`,{headers:this.headers()});return j.data.map(x=>x.attributes)}
  async listEggs(){const j=await fetchJson<PteroList<any>>(`${env.PTERODACTYL_URL}/api/application/eggs?per_page=100&include=tags`,{headers:this.headers()});return j.data.map(x=>x.attributes)}
  async listNodes(){const j=await fetchJson<PteroList<any>>(`${env.PTERODACTYL_URL}/api/application/nodes?per_page=100&include=allocations,servers`,{headers:this.headers()});return j.data.map(x=>x.attributes)}
  async listDeployableNodes(memory:number,disk:number){const j=await fetchJson<any>(`${env.PTERODACTYL_URL}/api/application/nodes/deployable?memory=${memory}&disk=${disk}`,{headers:this.headers()});return (j.data??[]).map((x:any)=>x.attributes??x)}
  async listNodeAllocations(nodeId:number){const j=await fetchJson<PteroList<any>>(`${env.PTERODACTYL_URL}/api/application/nodes/${nodeId}/allocations?per_page=100&filter[server_id]=`,{headers:this.headers()});return j.data.map(x=>x.attributes)}
  async findUser(email:string){const j=await fetchJson<PteroList<any>>(`${env.PTERODACTYL_URL}/api/application/users?per_page=100&filter[email]=${encodeURIComponent(email)}`,{headers:this.headers()});return j.data?.[0]?.attributes??null}
  async createUser(input:{email:string;username:string;password:string;first_name:string;last_name:string}){const j=await fetchJson<any>(`${env.PTERODACTYL_URL}/api/application/users`,{method:'POST',headers:this.headers(),body:JSON.stringify(input)});return j.attributes}
  async createServer(body:any){const j=await fetchJson<any>(`${env.PTERODACTYL_URL}/api/application/servers`,{method:'POST',headers:this.headers(),body:JSON.stringify(body)});return j.attributes}
  async getServer(id:number){const j=await fetchJson<any>(`${env.PTERODACTYL_URL}/api/application/servers/${id}?include=allocations,node,egg`,{headers:this.headers()});return j.attributes}
  async suspendServer(id:number){await fetchJson(`${env.PTERODACTYL_URL}/api/application/servers/${id}/suspend`,{method:'POST',headers:this.headers()});}
  async unsuspendServer(id:number){await fetchJson(`${env.PTERODACTYL_URL}/api/application/servers/${id}/unsuspend`,{method:'POST',headers:this.headers()});}
  async reinstallServer(id:number){await fetchJson(`${env.PTERODACTYL_URL}/api/application/servers/${id}/reinstall`,{method:'POST',headers:this.headers()});}
  async deleteServer(id:number,force=false){await fetchJson(`${env.PTERODACTYL_URL}/api/application/servers/${id}${force?'?force=true':''}`,{method:'DELETE',headers:this.headers()});}
  async updateBuild(id:number,body:any){const j=await fetchJson<any>(`${env.PTERODACTYL_URL}/api/application/servers/${id}/build`,{method:'PATCH',headers:this.headers(),body:JSON.stringify(body)});return j.attributes}
  async updateStartup(id:number,body:any){const j=await fetchJson<any>(`${env.PTERODACTYL_URL}/api/application/servers/${id}/startup`,{method:'PATCH',headers:this.headers(),body:JSON.stringify(body)});return j.attributes}
  async updateDetails(id:number,body:any){return fetchJson<any>(`${env.PTERODACTYL_URL}/api/application/servers/${id}/details`,{method:'PATCH',headers:this.headers(),body:JSON.stringify(body)})}
  async clientPower(clientKey:string,identifier:string,signal:'start'|'stop'|'restart'|'kill'){return fetchJson(`${env.PTERODACTYL_URL}${env.PTERODACTYL_CLIENT_API_BASE}/servers/${identifier}/power`,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${clientKey}`},body:JSON.stringify({signal})})}
  async clientResources(clientKey:string,identifier:string){return fetchJson<any>(`${env.PTERODACTYL_URL}${env.PTERODACTYL_CLIENT_API_BASE}/servers/${identifier}/resources`,{headers:{Authorization:`Bearer ${clientKey}`}})}
  async clientConsole(clientKey:string,identifier:string){return fetchJson<any>(`${env.PTERODACTYL_URL}${env.PTERODACTYL_CLIENT_API_BASE}/servers/${identifier}/websocket`,{headers:{Authorization:`Bearer ${clientKey}`}})}
  async clientBackups(clientKey:string,identifier:string){const j=await fetchJson<any>(`${env.PTERODACTYL_URL}${env.PTERODACTYL_CLIENT_API_BASE}/servers/${identifier}/backups`,{headers:{Authorization:`Bearer ${clientKey}`,'Accept':'application/json'}});return (j.data??[]).map((x:any)=>x.attributes??x)}
  async clientBackupDownload(clientKey:string,identifier:string,backupId:string){return fetchJson<any>(`${env.PTERODACTYL_URL}${env.PTERODACTYL_CLIENT_API_BASE}/servers/${identifier}/backups/${encodeURIComponent(backupId)}/download`,{headers:{Authorization:`Bearer ${clientKey}`,'Accept':'application/json'}})}
}
export const pterodactyl=new PterodactylService();
