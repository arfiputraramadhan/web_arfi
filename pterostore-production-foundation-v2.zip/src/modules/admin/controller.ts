import type {Request,Response} from 'express';import * as s from './service.js';import {audit} from './audit.js';import * as srv from '../servers/service.js';
export async function sync(req:Request,res:Response){const r=await s.syncCatalog();await audit((req as any).user.id,'CATALOG_SYNC',req,r);res.json({ok:true,result:r})}export async function summary(_req:Request,res:Response){res.json({ok:true,result:await s.summary()})}export async function users(req:Request,res:Response){res.json({ok:true,users:await s.listUsers(String(req.query.q||''))})}export async function ban(req:Request,res:Response){await s.setBan(req.params.id,req.body.banned===true);await audit((req as any).user.id,req.body.banned===true?'USER_BAN':'USER_UNBAN',req,{resourceId:req.params.id});res.json({ok:true})}export async function wallet(req:Request,res:Response){await s.adjustWallet(req.body.userId,Number(req.body.amount),String(req.body.reason||'admin'));await audit((req as any).user.id,'WALLET_ADJUST',req,{resourceId:req.body.userId,amount:Number(req.body.amount)});res.json({ok:true})}

export async function products(req:Request,res:Response){res.json({ok:true,products:await s.products()})}
export async function product(req:Request,res:Response){res.json({ok:true,product:await s.upsertProduct(req.body,req.params.id)})}
export async function productCreate(req:Request,res:Response){res.json({ok:true,product:await s.upsertProduct(req.body)})}
export async function vouchers(_req:Request,res:Response){res.json({ok:true,vouchers:await s.vouchers()})}
export async function voucherCreate(req:Request,res:Response){res.json({ok:true,voucher:await s.upsertVoucher(req.body)})}
export async function nodeList(_req:Request,res:Response){res.json({ok:true,nodes:await s.nodes()})}
export async function nodeToggle(req:Request,res:Response){res.json({ok:true,node:await s.toggleNode(req.params.id,req.body.enabled===true)})}
export async function exportOrders(_req:Request,res:Response){res.setHeader('Content-Type','text/csv');res.setHeader('Content-Disposition','attachment; filename=orders.csv');res.send(await s.ordersExport())}

export async function serverSuspend(req:Request,res:Response){await srv.adminSuspend(req.params.id);await audit((req as any).user.id,'SERVER_SUSPEND',req,{resourceType:'SERVER',resourceId:req.params.id});res.json({ok:true})}
export async function serverUnsuspend(req:Request,res:Response){await srv.adminUnsuspend(req.params.id);await audit((req as any).user.id,'SERVER_UNSUSPEND',req,{resourceType:'SERVER',resourceId:req.params.id});res.json({ok:true})}
