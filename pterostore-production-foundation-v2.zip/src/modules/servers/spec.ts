import { HttpError } from '../../utils/http.js';

export type ServerSpec = { ramMb: number; cpuPercent: number; diskGb: number };

// Batas spesifikasi yang boleh diminta user saat upgrade/downgrade. Sesuaikan dengan kapasitas node Anda.
export const SPEC_LIMITS = {
  ramMb: { min: 512, max: 32768 },
  cpuPercent: { min: 10, max: 800 },
  diskGb: { min: 1, max: 500 }
} as const;

function intInRange(value: unknown, min: number, max: number): number | null {
  const n = typeof value === 'number' ? value : typeof value === 'string' && value.trim() !== '' ? Number(value) : NaN;
  return Number.isInteger(n) && n >= min && n <= max ? n : null;
}

/** Validasi ketat: hanya bilangan bulat dalam rentang. Nilai negatif, NaN, desimal, atau terlalu besar ditolak. */
export function parseServerSpec(input: any): ServerSpec {
  const ramMb = intInRange(input?.ramMb, SPEC_LIMITS.ramMb.min, SPEC_LIMITS.ramMb.max);
  const cpuPercent = intInRange(input?.cpuPercent, SPEC_LIMITS.cpuPercent.min, SPEC_LIMITS.cpuPercent.max);
  const diskGb = intInRange(input?.diskGb, SPEC_LIMITS.diskGb.min, SPEC_LIMITS.diskGb.max);
  if (ramMb === null || cpuPercent === null || diskGb === null) {
    throw new HttpError(400, `Spesifikasi tidak valid. RAM ${SPEC_LIMITS.ramMb.min}-${SPEC_LIMITS.ramMb.max} MB, CPU ${SPEC_LIMITS.cpuPercent.min}-${SPEC_LIMITS.cpuPercent.max}%, Disk ${SPEC_LIMITS.diskGb.min}-${SPEC_LIMITS.diskGb.max} GB.`, 'INVALID_SPEC');
  }
  return { ramMb, cpuPercent, diskGb };
}

export function parseRenewMonths(value: unknown): number {
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isInteger(n) || ![1, 2, 3].includes(n)) throw new HttpError(400, 'Periode perpanjangan tidak valid.', 'INVALID_MONTHS');
  return n;
}

export function remainingDays(expiresAt: Date, now = new Date()): number {
  return Math.max(1, Math.ceil((expiresAt.getTime() - now.getTime()) / 86_400_000));
}

/** Selisih harga bulanan dikalikan sisa hari (basis 30 hari), dibulatkan ke rupiah. */
export function prorate(monthlyDiff: number, days: number): number {
  return Math.round((monthlyDiff * days) / 30);
}
