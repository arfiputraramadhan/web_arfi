import { prisma } from '../../lib/prisma.js';
import { pterodactyl } from '../pterodactyl/service.js';
import { decrypt, encrypt } from '../../utils/crypto.js';
import { HttpError } from '../../utils/http.js';
import { calcProductPrice } from '../../utils/money.js';
import { parseServerSpec, parseRenewMonths, remainingDays, prorate, type ServerSpec } from './spec.js';
export async function myServers(userId:string){return prisma.server.findMany({where:{userId},include:{node:true,egg:true},orderBy:{expiresAt:'asc'}})}
export async function setClientKey(userId:string,key:string){await prisma.user.update({where:{id:userId},data:{pteroClientApiKeyEnc:encrypt(key)}})}
async function getOwned(userId:string,id:string){const s=await prisma.server.findUnique({where:{id},include:{user:true,node:true,egg:true}});if(!s||s.userId!==userId)throw new HttpError(404,'Server tidak ditemukan.');return s}
export async function power(userId:string,id:string,signal:any){const s=await getOwned(userId,id); if(!s.pteroIdentifier)throw new HttpError(409,'Server belum siap.'); if(!s.user.pteroClientApiKeyEnc)throw new HttpError(400,'Simpan Client API Key Pterodactyl terlebih dahulu.'); await pterodactyl.clientPower(decrypt(s.user.pteroClientApiKeyEnc),s.pteroIdentifier,signal);}
export async function consoleInfo(userId:string,id:string){const s=await getOwned(userId,id);if(!s.pteroIdentifier||!s.user.pteroClientApiKeyEnc)throw new HttpError(400,'Client API Key belum tersedia.');return pterodactyl.clientConsole(decrypt(s.user.pteroClientApiKeyEnc),s.pteroIdentifier)}
export async function resources(userId:string,id:string){const s=await getOwned(userId,id);if(!s.pteroIdentifier||!s.user.pteroClientApiKeyEnc)throw new HttpError(400,'Client API Key belum tersedia.');return pterodactyl.clientResources(decrypt(s.user.pteroClientApiKeyEnc),s.pteroIdentifier)}
export async function reinstall(userId:string,id:string){const s=await getOwned(userId,id);if(!s.pteroServerId)throw new HttpError(409,'Server belum siap.');await pterodactyl.reinstallServer(s.pteroServerId)}
export async function refreshOne(userId:string,id:string){const s=await getOwned(userId,id);if(!s.pteroServerId)throw new HttpError(409,'Server belum siap.');const p=await pterodactyl.getServer(s.pteroServerId);await prisma.server.update({where:{id},data:{status:p.suspended?'SUSPENDED':s.status}});return p}

export async function backups(userId:string,id:string){
  const s=await getOwned(userId,id);
  if(!s.pteroIdentifier||!s.user.pteroClientApiKeyEnc)throw new HttpError(400,'Client API Key belum tersedia.');
  return pterodactyl.clientBackups(decrypt(s.user.pteroClientApiKeyEnc),s.pteroIdentifier);
}
export async function backupDownload(userId:string,id:string,backupId:string){
  const s=await getOwned(userId,id);
  if(!s.pteroIdentifier||!s.user.pteroClientApiKeyEnc)throw new HttpError(400,'Client API Key belum tersedia.');
  return pterodactyl.clientBackupDownload(decrypt(s.user.pteroClientApiKeyEnc),s.pteroIdentifier,backupId);
}


// ---------------------------------------------------------------------------
// Harga, saldo, perpanjangan, dan upgrade
// ---------------------------------------------------------------------------

/**
 * Harga per bulan untuk server dengan spesifikasi tertentu, dihitung dari data produk yang dibeli
 * (tarif per RAM/CPU/disk + pengali node dan egg), sehingga selalu konsisten dengan harga di checkout.
 * Flash sale hanya berlaku saat pembelian pertama, bukan saat perpanjangan.
 */
async function monthlyPriceFor(db: any, server: { orderId: string | null }, spec: ServerSpec): Promise<number> {
  const item = server.orderId
    ? await db.orderItem.findFirst({ where: { orderId: server.orderId }, include: { product: { include: { productNodes: true } } } })
    : null;
  if (!item) throw new HttpError(409, 'Data produk untuk server ini tidak ditemukan. Hubungi admin.', 'PRICING_UNAVAILABLE');
  const p = item.product;
  const pn = item.nodeId ? p.productNodes.find((x: any) => x.nodeId === item.nodeId) : null;
  return calcProductPrice({ ...p, ...spec, nodeMultiplierBps: pn?.multiplierBps ?? p.nodeMultiplierBps, eggMultiplierBps: p.eggMultiplierBps }, 1);
}

async function lockUser(tx: any, userId: string) {
  await tx.$queryRaw`SELECT id FROM "User" WHERE id=${userId} FOR UPDATE`;
}

/** Mencatat mutasi saldo. Wajib dipanggil setelah lockUser() di transaksi yang sama. Saldo tidak boleh negatif. */
async function applyWalletEntry(tx: any, userId: string, type: 'DEBIT' | 'CREDIT', amount: number, reason: string, referenceId: string) {
  if (!Number.isInteger(amount) || amount <= 0) throw new HttpError(400, 'Nominal tidak valid.', 'INVALID_AMOUNT');
  const last = await tx.walletEntry.findFirst({ where: { userId }, orderBy: { createdAt: 'desc' } });
  const balance = last?.balanceAfter ?? 0;
  const next = type === 'DEBIT' ? balance - amount : balance + amount;
  if (next < 0) throw new HttpError(400, 'Saldo tidak cukup.', 'INSUFFICIENT_BALANCE');
  await tx.walletEntry.create({ data: { userId, type, amount, balanceAfter: next, reason, referenceId } });
}

async function walletMove(userId: string, type: 'DEBIT' | 'CREDIT', amount: number, reason: string, referenceId: string) {
  await prisma.$transaction(async (tx) => {
    await lockUser(tx, userId);
    await applyWalletEntry(tx, userId, type, amount, reason, referenceId);
  });
}

/** Perpanjang server memakai saldo. Dipakai oleh tombol perpanjang user dan cron auto-renew. */
export async function renewWithWallet(userId: string, serverId: string, monthsRaw: unknown, reason = 'SERVER_RENEW') {
  const months = parseRenewMonths(monthsRaw);
  return prisma.$transaction(async (tx) => {
    await lockUser(tx, userId);
    const s = await tx.server.findUnique({ where: { id: serverId } });
    if (!s || s.userId !== userId) throw new HttpError(404, 'Server tidak ditemukan.');
    if (s.status === 'DELETED' || s.status === 'PROVISIONING') throw new HttpError(409, 'Server ini tidak dapat diperpanjang.', 'INVALID_STATE');
    const total = (await monthlyPriceFor(tx, s, s)) * months;
    if (total > 0) await applyWalletEntry(tx, userId, 'DEBIT', total, reason, serverId);
    const base = s.expiresAt > new Date() ? s.expiresAt : new Date();
    const updated = await tx.server.update({
      where: { id: serverId },
      data: { expiresAt: new Date(base.getTime() + months * 30 * 86_400_000), status: 'ACTIVE', graceUntil: null }
    });
    // Bila gagal di Pterodactyl, seluruh transaksi (termasuk debit saldo) dibatalkan.
    if (s.status === 'SUSPENDED' && s.pteroServerId) await pterodactyl.unsuspendServer(s.pteroServerId);
    return updated;
  }, { timeout: 20_000, maxWait: 5_000 });
}

export async function renew(userId: string, id: string, months: unknown) {
  return renewWithWallet(userId, id, months, 'SERVER_RENEW');
}

/**
 * Upgrade/downgrade spesifikasi. Urutan dibuat agar uang tidak hilang maupun tercetak:
 * validasi ketat -> hitung selisih dari harga produk -> debit (bila naik) -> ubah di Pterodactyl
 * -> bila Pterodactyl gagal, debit dikembalikan -> bila turun, kredit setelah Pterodactyl berhasil.
 */
export async function upgrade(userId: string, id: string, input: any) {
  const spec = parseServerSpec(input);
  const s = await getOwned(userId, id);
  if (!s.pteroServerId) throw new HttpError(409, 'Server belum siap.');
  if (s.status !== 'ACTIVE' || s.expiresAt <= new Date()) throw new HttpError(409, 'Upgrade hanya tersedia untuk server yang masih aktif.', 'INVALID_STATE');

  const current: ServerSpec = { ramMb: s.ramMb, cpuPercent: s.cpuPercent, diskGb: s.diskGb };
  const diff = (await monthlyPriceFor(prisma, s, spec)) - (await monthlyPriceFor(prisma, s, current));
  const delta = prorate(diff, remainingDays(s.expiresAt));

  const eggId = typeof input?.eggId === 'string' && input.eggId ? input.eggId : undefined;
  const egg = eggId ? await prisma.productEgg.findUnique({ where: { id: eggId } }) : null;
  if (eggId && !egg) throw new HttpError(400, 'Egg tidak ditemukan.', 'INVALID_EGG');

  if (delta > 0) await walletMove(userId, 'DEBIT', delta, 'SERVER_UPGRADE', id);
  try {
    const remote = await pterodactyl.getServer(s.pteroServerId);
    const allocationId = typeof remote.allocation === 'number' ? remote.allocation : remote.allocation?.id;
    await pterodactyl.updateBuild(s.pteroServerId, {
      allocation: allocationId,
      limits: { memory: spec.ramMb, swap: 0, disk: spec.diskGb * 1024, cpu: spec.cpuPercent, io: 500 },
      feature_limits: { databases: 0, allocations: 1, backups: 1 }
    });
  } catch (e) {
    if (delta > 0) await walletMove(userId, 'CREDIT', delta, 'SERVER_UPGRADE_REVERT', id).catch((err) => console.error('upgrade_revert_failed', id, err));
    throw e;
  }
  if (delta < 0) await walletMove(userId, 'CREDIT', -delta, 'SERVER_DOWNGRADE', id);

  let eggApplied = false; let eggError: unknown = null;
  if (egg) {
    try {
      await pterodactyl.updateStartup(s.pteroServerId, { startup: egg.startup || 'bash', egg: egg.pteroId, image: egg.dockerImage || 'ghcr.io/pterodactyl/yolks:java_21', environment: {} });
      eggApplied = true;
    } catch (e) { eggError = e; }
  }
  const updated = await prisma.server.update({ where: { id }, data: { ...spec, eggId: eggApplied && egg ? egg.id : s.eggId } });
  if (eggError) throw new HttpError(502, 'Spesifikasi berhasil diperbarui, tetapi penggantian egg gagal. Hubungi admin.', 'EGG_CHANGE_FAILED');
  return updated;
}

// ---------------------------------------------------------------------------
// Khusus admin (tanpa cek kepemilikan). Endpoint untuk user sengaja dihapus agar user
// tidak bisa mengaktifkan kembali server yang sudah kedaluwarsa tanpa membayar.
// ---------------------------------------------------------------------------
export async function adminSuspend(id: string) {
  const s = await prisma.server.findUnique({ where: { id } });
  if (!s) throw new HttpError(404, 'Server tidak ditemukan.');
  if (!s.pteroServerId) throw new HttpError(409, 'Server belum siap.');
  await pterodactyl.suspendServer(s.pteroServerId);
  await prisma.server.update({ where: { id }, data: { status: 'SUSPENDED' } });
}

export async function adminUnsuspend(id: string) {
  const s = await prisma.server.findUnique({ where: { id } });
  if (!s) throw new HttpError(404, 'Server tidak ditemukan.');
  if (!s.pteroServerId) throw new HttpError(409, 'Server belum siap.');
  if (s.status === 'DELETED') throw new HttpError(409, 'Server sudah dihapus.', 'INVALID_STATE');
  if (s.expiresAt <= new Date()) throw new HttpError(409, 'Masa aktif server sudah lewat. Perpanjang dulu agar tidak disuspend ulang oleh cron.', 'EXPIRED');
  await pterodactyl.unsuspendServer(s.pteroServerId);
  await prisma.server.update({ where: { id }, data: { status: 'ACTIVE', graceUntil: null } });
}
