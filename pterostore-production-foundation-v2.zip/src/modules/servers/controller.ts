import type {Request,Response} from 'express'; import * as svc from './service.js';
export async function list(req:Request,res:Response){res.json({ok:true,servers:await svc.myServers((req as any).user.id)})}
export async function saveKey(req:Request,res:Response){await svc.setClientKey((req as any).user.id,req.body.key);res.json({ok:true})}
export async function power(req:Request,res:Response){await svc.power((req as any).user.id,req.params.id,req.body.signal);res.json({ok:true})}
export async function consoleInfo(req:Request,res:Response){res.json({ok:true,data:await svc.consoleInfo((req as any).user.id,req.params.id)})}
export async function resources(req:Request,res:Response){res.json({ok:true,data:await svc.resources((req as any).user.id,req.params.id)})}
export async function reinstall(req:Request,res:Response){await svc.reinstall((req as any).user.id,req.params.id);res.json({ok:true})}
export async function refresh(req:Request,res:Response){res.json({ok:true,data:await svc.refreshOne((req as any).user.id,req.params.id)})}
export async function backups(req:Request,res:Response){res.json({ok:true,data:await svc.backups((req as any).user.id,req.params.id)})}
export async function backupDownload(req:Request,res:Response){res.json({ok:true,data:await svc.backupDownload((req as any).user.id,req.params.id,req.params.backupId)})}

export async function renew(req:Request,res:Response){res.json({ok:true,server:await svc.renew((req as any).user.id,req.params.id,req.body?.months)})}
export async function upgrade(req:Request,res:Response){res.json({ok:true,server:await svc.upgrade((req as any).user.id,req.params.id,req.body)})}
