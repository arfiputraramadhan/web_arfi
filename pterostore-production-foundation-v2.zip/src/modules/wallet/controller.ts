import type {Request,Response} from 'express';import {prisma} from '../../lib/prisma.js';
export async function balance(req:Request,res:Response){const e=await prisma.walletEntry.findFirst({where:{userId:(req as any).user.id},orderBy:{createdAt:'desc'}});res.json({ok:true,balance:e?.balanceAfter??0})}
export async function history(req:Request,res:Response){res.json({ok:true,entries:await prisma.walletEntry.findMany({where:{userId:(req as any).user.id},orderBy:{createdAt:'desc'},take:100})})}
