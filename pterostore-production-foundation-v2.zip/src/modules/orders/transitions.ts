export type OrderStatus = 'PENDING' | 'PAID' | 'PROVISIONING' | 'ACTIVE' | 'EXPIRING' | 'SUSPENDED' | 'CANCELLED' | 'EXPIRED' | 'FAILED' | 'DELETED';

export const transitions: Record<OrderStatus, OrderStatus[]> = {
  PENDING: ['PAID', 'CANCELLED', 'EXPIRED'],
  PAID: ['PROVISIONING', 'CANCELLED', 'FAILED'],
  PROVISIONING: ['ACTIVE', 'FAILED'],
  ACTIVE: ['EXPIRING', 'SUSPENDED', 'DELETED'],
  EXPIRING: ['ACTIVE', 'SUSPENDED'],
  SUSPENDED: ['ACTIVE', 'DELETED'],
  CANCELLED: [],
  EXPIRED: [],
  FAILED: [],
  DELETED: []
};

export function canTransition(from: string, to: string): boolean {
  return (transitions as Record<string, string[]>)[from]?.includes(to) ?? false;
}
