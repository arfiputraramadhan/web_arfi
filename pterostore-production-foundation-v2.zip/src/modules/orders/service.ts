import { prisma } from '../../lib/prisma.js';
import { calcProductPrice, applyDiscount } from '../../utils/money.js';
import { HttpError } from '../../utils/http.js';
import { pakasir } from '../payments/pakasir.js';
import { queueProvisioning } from '../../workers/queue.js';
import { env } from '../../config/env.js';
import { canTransition } from './transitions.js';

export async function transitionOrder(tx:any,orderId:string,to:any,reason:string,actorType='SYSTEM',actorId?:string){const order=await tx.order.findUnique({where:{id:orderId}});if(!order)throw new HttpError(404,'Order tidak ditemukan.');if(!canTransition(order.status,to))throw new HttpError(409,`Transisi ${order.status}->${to} tidak diizinkan.`,'INVALID_STATE_TRANSITION');const updated=await tx.order.updateMany({where:{id:orderId,status:order.status,stateVersion:order.stateVersion},data:{status:to,stateVersion:{increment:1},...(to==='PAID'?{paidAt:new Date()}:{}),...(to==='FAILED'?{failedAt:new Date(),failureReason:reason}:{}),...(to==='CANCELLED'?{canceledAt:new Date()}: {})}}); if(updated.count!==1) throw new HttpError(409,'State berubah bersamaan.','CONCURRENT_STATE_CHANGE');await tx.orderStateTransition.create({data:{orderId,from:order.status,to,reason,actorType,actorId}});}
export async function quote(userId:string,productId:string,input:{months?:number;ramMb?:number;cpuPercent?:number;diskGb?:number;voucherCode?:string;nodeId?:string}){
  const p=await prisma.product.findUniqueOrThrow({where:{id:productId},include:{egg:true,productNodes:{include:{node:true}}}});
  if(!p.active)throw new HttpError(400,'Produk tidak aktif.');
  const candidateNodes=p.productNodes.filter((x:any)=>x.enabled&&x.node.sellingEnabled);
  const chosen=input.nodeId?candidateNodes.find((x:any)=>x.nodeId===input.nodeId):candidateNodes[0];
  if(input.nodeId && !chosen)throw new HttpError(409,'Node tidak tersedia untuk produk ini.','NODE_UNAVAILABLE');
  if(!chosen && p.productNodes.length)throw new HttpError(409,'Belum ada node penjualan yang tersedia.','NODE_UNAVAILABLE');
  const item={ramMb:Math.max(512,input.ramMb??p.ramMb??2048),cpuPercent:Math.max(10,input.cpuPercent??p.cpuPercent??100),diskGb:Math.max(1,input.diskGb??p.diskGb??10)};
  let amount=calcProductPrice({...p,...item,nodeMultiplierBps:chosen?.multiplierBps??p.nodeMultiplierBps,eggMultiplierBps:p.eggMultiplierBps},input.months??1);
  const flashActive=p.flashSaleStart&&p.flashSaleEnd&&p.flashSaleStart<=new Date()&&p.flashSaleEnd>=new Date()&&p.flashSalePrice;
  if(flashActive)amount=Number(p.flashSalePrice)*(input.months??1);
  let discount=0;let voucher:any=null;
  if(input.voucherCode){voucher=await prisma.voucher.findUnique({where:{code:input.voucherCode.toUpperCase()},include:{products:true}});if(voucher&&voucher.active&&( !voucher.startsAt||voucher.startsAt<=new Date())&&( !voucher.endsAt||voucher.endsAt>=new Date())){const red=await prisma.voucherRedemption.count({where:{voucherId:voucher.id,userId}});if(red<voucher.perUserLimit&&(!voucher.quota||voucher.usedCount<voucher.quota)){const allowed=!voucher.products.length||voucher.products.some((x:any)=>x.productId===p.id);if(allowed)discount=applyDiscount(amount,voucher)}}}
  return {product:p,node:chosen?.node??null,nodeMultiplierBps:chosen?.multiplierBps??p.nodeMultiplierBps,item,subtotal:amount,discount,total:amount-discount,voucherId:voucher&&discount?voucher.id:null};
}
export async function createOrder(userId:string,input:any){
 const q=await quote(userId,input.productId,input); if(q.total<500)throw new HttpError(400,'Nominal minimal pembayaran adalah Rp500.');
 const number=`PS${Date.now().toString(36).toUpperCase()}${Math.random().toString(36).slice(2,7).toUpperCase()}`;
 if(input.paymentMethod==='wallet'){
   const order=await prisma.$transaction(async tx=>{
     await tx.$queryRaw`SELECT id FROM "User" WHERE id=${userId} FOR UPDATE`;
     const last=await tx.walletEntry.findFirst({where:{userId},orderBy:{createdAt:'desc'}});const balance=last?.balanceAfter??0;if(balance<q.total)throw new HttpError(400,'Saldo tidak cukup.','INSUFFICIENT_BALANCE');
     const o=await tx.order.create({data:{userId,number,amount:q.total,paymentMethod:'WALLET',discount:q.discount,items:{create:{productId:q.product.id,nodeId:q.node?.id??undefined,months:input.months??1,ramMb:q.item.ramMb,cpuPercent:q.item.cpuPercent,diskGb:q.item.diskGb,unitPrice:Math.floor(q.subtotal/(input.months??1)),subtotal:q.subtotal}}}});
     if(q.voucherId){await tx.voucherRedemption.create({data:{voucherId:q.voucherId,userId,orderId:o.id,discount:q.discount}});await tx.voucher.update({where:{id:q.voucherId},data:{usedCount:{increment:1}}});}
     await tx.walletEntry.create({data:{userId,type:'DEBIT',amount:q.total,balanceAfter:balance-q.total,reason:'ORDER_PAYMENT_WALLET',referenceId:o.id}});
     await tx.walletPayment.create({data:{userId,orderId:o.id,amount:q.total}});
     await tx.order.update({where:{id:o.id},data:{status:'PAID',paidAt:new Date(),stateVersion:{increment:1}}});await tx.orderStateTransition.create({data:{orderId:o.id,to:'PENDING',actorType:'USER',actorId:userId,reason:'ORDER_CREATED'}});await tx.orderStateTransition.create({data:{orderId:o.id,from:'PENDING',to:'PAID',actorType:'SYSTEM',reason:'WALLET_PAID'}});await tx.order.update({where:{id:o.id},data:{status:'PROVISIONING',stateVersion:{increment:1}}});await tx.orderStateTransition.create({data:{orderId:o.id,from:'PAID',to:'PROVISIONING',actorType:'SYSTEM',reason:'QUEUE_PROVISIONING'}});return o;
   });
   await queueProvisioning(order.id);return order;
 }
 const order=await prisma.$transaction(async tx=>{const o=await tx.order.create({data:{userId,number,amount:q.total,paymentMethod:'QRIS',voucherCode:input.voucherCode?.toUpperCase(),discount:q.discount,items:{create:{productId:q.product.id,nodeId:q.node?.id??undefined,months:input.months??1,ramMb:q.item.ramMb,cpuPercent:q.item.cpuPercent,diskGb:q.item.diskGb,unitPrice:Math.floor(q.subtotal/(input.months??1)),subtotal:q.subtotal}}}});if(q.voucherId){await tx.voucherRedemption.create({data:{voucherId:q.voucherId,userId,orderId:o.id,discount:q.discount}});await tx.voucher.update({where:{id:q.voucherId},data:{usedCount:{increment:1}}});}await tx.orderStateTransition.create({data:{orderId:o.id,to:'PENDING',actorType:'USER',actorId:userId,reason:'ORDER_CREATED'}});return o;});
 const p=await pakasir.create(order.number,order.amount,'qris');const qr=p.qr_string?await pakasir.qrDataUrl(p.qr_string):undefined;
 const updated=await prisma.order.update({where:{id:order.id},data:{totalPayment:p.total_payment,paymentNumber:p.va_number||undefined,qrString:p.qr_string,paymentLink:p.payment_link??`${env.PAKASIR_BASE_URL}/pay-v2/${p.txn_id}?qris_only=1`,pakasirTxnId:p.txn_id,paymentExpiresAt:new Date(p.expired_at)}});
 return {...updated,qrDataUrl:qr};
}
export async function processPaid(orderId:string){
  await prisma.$transaction(async tx=>{
    await transitionOrder(tx,orderId,'PAID','PAKASIR_CONFIRMED');
    await transitionOrder(tx,orderId,'PROVISIONING','QUEUE_PROVISIONING');
    const o=await tx.order.findUnique({where:{id:orderId},include:{user:true}});
    if(o?.user.referredByCodeId){
      const code=await tx.referralCode.findUnique({where:{id:o.user.referredByCodeId}});
      if(code){
        const exists=await tx.referralBonus.findFirst({where:{codeId:code.id,orderId:o.id}});
        if(!exists){
          const bonus=Math.floor(o.amount*5/100);
          if(bonus>0){
            const last=await tx.walletEntry.findFirst({where:{userId:code.userId},orderBy:{createdAt:'desc'}});
            await tx.walletEntry.create({data:{userId:code.userId,type:'CREDIT',amount:bonus,balanceAfter:(last?.balanceAfter??0)+bonus,reason:'REFERRAL_BONUS',referenceId:o.id}});
            await tx.referralBonus.create({data:{codeId:code.id,referredUserId:o.userId,orderId:o.id,amount:bonus}});
          }
        }
      }
    }
  });
  await queueProvisioning(orderId);
}
