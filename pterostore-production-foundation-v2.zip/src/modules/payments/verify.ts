/** Nominal dari webhook harus bilangan bulat dan sama persis dengan nominal di database. */
export function amountMatches(expected: number, received: unknown): boolean {
  const n = Number(received);
  return Number.isInteger(n) && n === expected;
}

/** Pembayaran dianggap sah hanya bila status Pakasir "completed" dan order_id serta nominalnya cocok. */
export function isConfirmedPayment(
  remote: { order_id: string; amount: number; status: string } | null | undefined,
  expectedAmount: number,
  orderNumber: string
): boolean {
  return !!remote && remote.status === 'completed' && remote.amount === expectedAmount && remote.order_id === orderNumber;
}
