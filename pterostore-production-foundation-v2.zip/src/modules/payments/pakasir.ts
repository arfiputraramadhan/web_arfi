import QRCode from 'qrcode';
import { env } from '../../config/env.js';
import { fetchJson } from '../../utils/http.js';

type CreateResp={txn_id:string;project:string;order_id:string;amount:number;fee:number;total_payment:number;payment_method:string;qr_string?:string;va_number?:string;expired_at:string;payment_link?:string;is_sandbox:boolean};
type StatusResp={txn_id:string;order_id:string;amount:number;is_sandbox:boolean;status:'pending'|'completed'|'canceled';completed_at?:string};
export class PakasirService {
  private headers(){return {'Content-Type':'application/json','X-Api-Key':env.PAKASIR_API_KEY};}
  async create(orderId:string,amount:number,method=env.PAKASIR_PAYMENT_METHOD){return fetchJson<CreateResp>(`${env.PAKASIR_BASE_URL}/api/v2/create-transaction/${encodeURIComponent(env.PAKASIR_SLUG)}/${encodeURIComponent(orderId)}`,{method:'POST',headers:this.headers(),body:JSON.stringify({method,amount})});}
  async status(txnId:string){return fetchJson<StatusResp>(`${env.PAKASIR_BASE_URL}/api/v2/transaction-status/${encodeURIComponent(env.PAKASIR_SLUG)}/${encodeURIComponent(txnId)}`,{headers:{'X-Api-Key':env.PAKASIR_API_KEY}});}
  async cancel(txnId:string){return fetchJson<{message:string}>(`${env.PAKASIR_BASE_URL}/api/v2/cancel-transaction/${encodeURIComponent(env.PAKASIR_SLUG)}/${encodeURIComponent(txnId)}`,{method:'POST',headers:{'X-Api-Key':env.PAKASIR_API_KEY}});}
  async simulate(orderId:string,amount:number){if(!env.PAKASIR_ENABLE_SIMULATION||env.NODE_ENV==='production') throw new Error('SIMULATION_DISABLED');return fetchJson(`${env.PAKASIR_BASE_URL}/api/paymentsimulation`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({project:env.PAKASIR_SLUG,order_id:orderId,amount,api_key:env.PAKASIR_API_KEY})});}
  async qrDataUrl(qrString:string){return QRCode.toDataURL(qrString,{margin:1,width:320});}
}
export const pakasir=new PakasirService();
