import { Router } from 'express';
import { z } from 'zod';
import { registerC, resendC, verifyC, loginC, meC, logoutC, logoutAllC, resetRequestC, resetC } from './controller.js';
import { csrfGuard, csrfIssue } from '../../middleware/csrf.js';
import { requireAuth } from '../../middleware/auth.js';

import { rateLimit } from '../../middleware/rateLimit.js';import { captcha } from '../../middleware/captcha.js';
const r=Router();
const validate=(schema:any)=>(req:any,_res:any,next:any)=>{req.body=schema.parse(req.body);next()};
r.get('/csrf', requireAuth, csrfIssue);
r.post('/register',captcha,rateLimit('rl:register',5,60),validate(z.object({username:z.string(),email:z.string().email(),phone:z.string(),password:z.string(),confirmPassword:z.string(),referralCode:z.string().optional()})),registerC);
r.post('/register/verify',rateLimit('rl:otp',5,60),validate(z.object({pendingKey:z.string(),code:z.string().length(6)})),verifyC);
r.post('/login',captcha,rateLimit('rl:login',10,60),validate(z.object({identifier:z.string(),password:z.string(),totp:z.string().regex(/^\d{6}$/).optional()})),loginC);
r.post('/register/resend',rateLimit('rl:otp-resend',3,60),validate(z.object({pendingKey:z.string()})),resendC);
r.post('/password/request',captcha,rateLimit('rl:reset',5,300),validate(z.object({email:z.string().email()})),resetRequestC);
r.post('/password/reset',rateLimit('rl:reset2',5,300),validate(z.object({token:z.string(),password:z.string()})),resetC);
r.get('/me',meC);
r.post('/logout',requireAuth,csrfGuard,logoutC); r.post('/logout-all',requireAuth,csrfGuard,logoutAllC); 
export default r;
