import { prisma } from '../../lib/prisma.js';
import { redis } from '../../lib/redis.js';
import { encrypt, decrypt } from '../../utils/crypto.js';
import { HttpError } from '../../utils/http.js';
import { generateSecret, keyUri, verifyTotp } from '../../utils/totp.js';

const MAX_FAILS = 5;
const FAIL_WINDOW_SEC = 300;

/**
 * Memeriksa kode TOTP dengan tiga pengaman:
 * 1) maksimal 5 kode salah per 5 menit per akun (anti brute force 6 digit),
 * 2) kode yang sudah dipakai tidak bisa dipakai lagi (anti replay),
 * 3) toleransi selisih jam 1 langkah (30 detik).
 */
async function consumeTotp(userId: string, secretEnc: string, token: string): Promise<boolean> {
  const failKey = `totp:fail:${userId}`;
  const fails = Number((await redis.get(failKey)) || 0);
  if (fails >= MAX_FAILS) throw new HttpError(429, 'Terlalu banyak kode 2FA salah. Coba lagi beberapa menit lagi.', 'TOTP_LOCKED');
  const counter = verifyTotp(decrypt(secretEnc), token);
  if (counter === null) {
    const n = await redis.incr(failKey);
    if (n === 1) await redis.expire(failKey, FAIL_WINDOW_SEC);
    return false;
  }
  const fresh = await redis.set(`totp:used:${userId}:${counter}`, '1', 'EX', 120, 'NX');
  if (fresh !== 'OK') return false;
  await redis.del(failKey);
  return true;
}

/** Dipakai saat login. Mengembalikan false untuk kode salah/terpakai; melempar 429 bila terkunci. */
export async function checkLoginTotp(userId: string, secretEnc: string | null, token: string): Promise<boolean> {
  if (!secretEnc) return false;
  return consumeTotp(userId, secretEnc, token);
}

export async function setup(userId: string) {
  const u = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  // Mencegah secret yang sedang dipakai ditimpa oleh siapa pun yang memegang sesi.
  if (u.totpEnabled) throw new HttpError(409, '2FA sudah aktif. Nonaktifkan dulu dengan kode 2FA saat ini bila ingin mengganti.', 'TOTP_ALREADY_ENABLED');
  const secret = generateSecret();
  await prisma.user.update({ where: { id: userId }, data: { totpSecretEnc: encrypt(secret) } });
  return { secret, otpauth: keyUri(u.username, 'PteroStore', secret) };
}

export async function verify(userId: string, token: string) {
  const u = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  if (u.totpEnabled) throw new HttpError(409, '2FA sudah aktif.', 'TOTP_ALREADY_ENABLED');
  if (!u.totpSecretEnc) throw new HttpError(400, '2FA belum disiapkan.');
  if (!(await consumeTotp(userId, u.totpSecretEnc, String(token || '')))) throw new HttpError(400, 'Kode 2FA salah.', 'TOTP_INVALID');
  await prisma.user.update({ where: { id: userId }, data: { totpEnabled: true } });
}

export async function disable(userId: string, token: string) {
  const u = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  if (!u.totpEnabled || !u.totpSecretEnc) throw new HttpError(409, '2FA tidak aktif.', 'TOTP_NOT_ENABLED');
  // Menonaktifkan 2FA wajib membuktikan kepemilikan kode saat ini.
  if (!(await consumeTotp(userId, u.totpSecretEnc, String(token || '')))) throw new HttpError(400, 'Kode 2FA salah.', 'TOTP_INVALID');
  await prisma.user.update({ where: { id: userId }, data: { totpEnabled: false, totpSecretEnc: null } });
}
