import argon2 from 'argon2';
import { prisma } from '../../lib/prisma.js';
import { redis } from '../../lib/redis.js';
import { env } from '../../config/env.js';
import { normalizeEmail, normalizePhone, randomToken, sha256, encrypt } from '../../utils/crypto.js';
import { HttpError } from '../../utils/http.js';
import { sendMail } from '../notifications/service.js';
import { checkLoginTotp } from './twofa.js';

const generic = 'Jika data valid, proses akan dilanjutkan.';
function strongPassword(p:string){return p.length>=12 && /[A-Z]/.test(p)&&/[a-z]/.test(p)&&/\d/.test(p)&&/[^A-Za-z0-9]/.test(p)}

export async function register(input:{username:string;email:string;phone:string;password:string;confirmPassword:string;referralCode?:string}){
  const email=normalizeEmail(input.email), phone=normalizePhone(input.phone);
  if(input.password!==input.confirmPassword || !strongPassword(input.password)) throw new HttpError(400,'Password tidak memenuhi kebijakan.','WEAK_PASSWORD');
  if(!/^[a-zA-Z0-9_]{3,32}$/.test(input.username)) throw new HttpError(400,'Username tidak valid.','INVALID_USERNAME');
  const disposable = /@(10minutemail|tempmail|guerrillamail|mailinator)\./i.test(email); if(disposable) throw new HttpError(400,'Email tidak didukung.','INVALID_EMAIL');
  const exists=await prisma.user.findFirst({where:{OR:[{username:input.username},{email},{phone}]}}); if(exists) return {ok:true,message:generic};
  const pendingKey=sha256(`${email}:${phone}:${input.username}`); const code=String(Math.floor(100000+Math.random()*900000));
  await prisma.otpCode.deleteMany({where:{pendingKey,purpose:'REGISTER'}});
  await prisma.otpCode.create({data:{pendingKey,purpose:'REGISTER',codeHash:await argon2.hash(code),expiresAt:new Date(Date.now()+env.OTP_TTL_SEC*1000)}});
  await prisma.setting.upsert({where:{key:`pending:${pendingKey}`},update:{value:JSON.stringify({username:input.username,email,phone,referralCode:input.referralCode?.toUpperCase(),passwordHash:await argon2.hash(input.password,{type:argon2.argon2id})})},create:{key:`pending:${pendingKey}`,value:JSON.stringify({username:input.username,email,phone,referralCode:input.referralCode?.toUpperCase(),passwordHash:await argon2.hash(input.password,{type:argon2.argon2id})})}});
  await sendMail(email,'Kode OTP PteroStore',`<h1>Verifikasi akun</h1><p>Kode OTP Anda:</p><p style="font-size:32px;font-weight:800;letter-spacing:8px">${code}</p><p>Berlaku 5 menit.</p>`);
  return {ok:true,pendingKey};
}
export async function resendRegistration(pendingKey:string){
  const pending=await prisma.setting.findUnique({where:{key:`pending:${pendingKey}`}});if(!pending)throw new HttpError(400,generic,'OTP_INVALID');
  const existing=await prisma.otpCode.findFirst({where:{pendingKey,purpose:'REGISTER'},orderBy:{createdAt:'desc'}});if(existing&&Date.now()-existing.lastSentAt.getTime()<env.OTP_COOLDOWN_SEC*1000)throw new HttpError(429,'Tunggu sebelum meminta OTP baru.','OTP_COOLDOWN');
  const d=JSON.parse(pending.value);const code=String(Math.floor(100000+Math.random()*900000));await prisma.otpCode.deleteMany({where:{pendingKey,purpose:'REGISTER'}});await prisma.otpCode.create({data:{pendingKey,purpose:'REGISTER',codeHash:await argon2.hash(code),expiresAt:new Date(Date.now()+env.OTP_TTL_SEC*1000)}});await prisma.setting.update({where:{key:pending.key},data:{updatedAt:new Date()}});await sendMail(d.email,'Kode OTP PteroStore',`<h1>Verifikasi akun</h1><p>Kode OTP baru:</p><p style="font-size:32px;font-weight:800;letter-spacing:8px">${code}</p><p>Berlaku 5 menit.</p>`);return {ok:true,message:generic};
}
export async function verifyRegistration(pendingKey:string,code:string){
  const otp=await prisma.otpCode.findFirst({where:{pendingKey,purpose:'REGISTER'},orderBy:{createdAt:'desc'}}); if(!otp||otp.expiresAt<new Date()||otp.attempts>=otp.maxAttempts) throw new HttpError(400,generic,'OTP_INVALID');
  if(!(await argon2.verify(otp.codeHash,code))){await prisma.otpCode.update({where:{id:otp.id},data:{attempts:{increment:1}}});throw new HttpError(400,generic,'OTP_INVALID');}
  const pending=await prisma.setting.findUnique({where:{key:`pending:${pendingKey}`}}); if(!pending) throw new HttpError(400,generic,'OTP_INVALID'); const d=JSON.parse(pending.value);
  const referral=d.referralCode?await prisma.referralCode.findUnique({where:{code:d.referralCode}}):null;const user=await prisma.user.create({data:{username:d.username,email:d.email,phone:d.phone,passwordHash:d.passwordHash,emailVerifiedAt:new Date(),phoneVerifiedAt:new Date(),referredByCodeId:referral?.id}});
  await prisma.setting.delete({where:{key:pending.key}}); await prisma.otpCode.deleteMany({where:{pendingKey,purpose:'REGISTER'}});
  return user;
}
export async function login(identifier:string,password:string,ip="unknown",totp?:string){
  const cleaned=identifier.trim(); const phoneCandidate=/^(0|62|8)\d{6,15}$/.test(cleaned.replace(/\D/g,'')) ? normalizePhone(cleaned) : null; const normalized = cleaned.includes('@') ? normalizeEmail(cleaned) : cleaned;
  const user=await prisma.user.findFirst({where:{OR:[{username:normalized},{email:normalized},...(phoneCandidate?[{phone:phoneCandidate}]:[])]}});
  const passwordOk=!!user && user.status!=='BANNED' && await argon2.verify(user.passwordHash,password);
  // Langkah 2: bila 2FA aktif, kode TOTP wajib valid sebelum sesi dibuat.
  let ok=passwordOk; let needTotp=false;
  if(passwordOk && user!.totpEnabled){
    if(!totp) { needTotp=true; ok=false; }
    else ok=await checkLoginTotp(user!.id,user!.totpSecretEnc,totp);
  }
  await prisma.loginAttempt.create({data:{userId:user?.id,identifierHash:sha256(normalized),ipHash:sha256(ip),successful:ok}}).catch(()=>{});
  if(needTotp) throw new HttpError(401,'Masukkan kode 2FA dari aplikasi authenticator.','TOTP_REQUIRED');
  if(!ok) throw new HttpError(401,'Login gagal.','AUTH_FAILED');
  return user!;
}
export async function createSession(userId:string,ua:string|undefined,ip:string|undefined){
  const token=randomToken(48), csrf=randomToken(24), tokenHash=sha256(token);
  const s=await prisma.session.create({data:{userId,tokenHash,csrfHash:sha256(csrf),userAgent:ua,ipHash:ip?sha256(ip):undefined,expiresAt:new Date(Date.now()+env.SESSION_TTL_SEC*1000)},include:{user:true}});
  return {s,token,csrf};
}
export async function logout(token?:string){if(!token)return; const hash=sha256(token); const s=await prisma.session.findUnique({where:{tokenHash:hash}}); if(!s)return; await prisma.session.update({where:{id:s.id},data:{status:'REVOKED'}}); await redis.del(`session:${hash}`);}
export async function logoutAll(userId:string){const sessions=await prisma.session.findMany({where:{userId,status:'ACTIVE'},select:{tokenHash:true}});await prisma.session.updateMany({where:{userId,status:'ACTIVE'},data:{status:'REVOKED'}});if(sessions.length)await redis.del(...sessions.map(s=>`session:${s.tokenHash}`));}
export async function requestReset(email:string){ const user=await prisma.user.findUnique({where:{email:normalizeEmail(email)}}); if(user){ const raw=randomToken(32); await prisma.passwordResetToken.create({data:{userId:user.id,tokenHash:sha256(raw),expiresAt:new Date(Date.now()+env.RESET_TTL_SEC*1000)}}); const url=`${env.APP_ORIGIN}/reset.html?token=${encodeURIComponent(raw)}`; await sendMail(user.email,'Reset password PteroStore',`<h1>Reset password</h1><p><a href="${url}">Buka halaman reset password</a></p><p>Link berlaku 15 menit.</p>`); } return {ok:true,message:generic}; }
export async function resetPassword(raw:string,newPassword:string){ if(!strongPassword(newPassword)) throw new HttpError(400,'Password tidak memenuhi kebijakan.','WEAK_PASSWORD'); const t=await prisma.passwordResetToken.findFirst({where:{tokenHash:sha256(raw),usedAt:null}}); if(!t||t.expiresAt<new Date()) throw new HttpError(400,generic,'RESET_INVALID'); const hash=await argon2.hash(newPassword,{type:argon2.argon2id}); const sessions=await prisma.session.findMany({where:{userId:t.userId,status:'ACTIVE'},select:{tokenHash:true}}); await prisma.$transaction([prisma.user.update({where:{id:t.userId},data:{passwordHash:hash}}),prisma.passwordResetToken.update({where:{id:t.id},data:{usedAt:new Date()}}),prisma.session.updateMany({where:{userId:t.userId,status:'ACTIVE'},data:{status:'REVOKED'}})]); if(sessions.length)await redis.del(...sessions.map(s=>`session:${s.tokenHash}`)); const u=await prisma.user.findUniqueOrThrow({where:{id:t.userId}}); await sendMail(u.email,'Password PteroStore berubah','<h1>Password berhasil diubah</h1><p>Semua sesi lama telah dicabut.</p>'); }
