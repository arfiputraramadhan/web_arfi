import nodemailer from 'nodemailer';
import { env } from '../../config/env.js';
import { logger } from '../../lib/logger.js';
export const mailer=nodemailer.createTransport({host:env.SMTP_HOST,port:env.SMTP_PORT,secure:env.SMTP_SECURE,auth:{user:env.SMTP_USER,pass:env.SMTP_PASS}});
export async function sendMail(to:string,subject:string,html:string){await mailer.sendMail({from:env.SMTP_FROM,to,subject,html}); logger.info({to,subject},'email_sent');}
