export function clampInt(n: number, min = 0, max = 2_147_483_647) { return Math.min(max, Math.max(min, Math.trunc(n))); }
export function calcProductPrice(p: {basePrice:number; ramPricePerGb:number; cpuPricePerCore:number; diskPricePerGb:number; ramMb:number; cpuPercent:number; diskGb:number; nodeMultiplierBps:number; eggMultiplierBps:number}, months=1) {
  const ramGb = Math.ceil(p.ramMb / 1024);
  const cpuCores = Math.max(1, Math.ceil(p.cpuPercent / 100));
  const raw = p.basePrice + ramGb*p.ramPricePerGb + cpuCores*p.cpuPricePerCore + p.diskGb*p.diskPricePerGb;
  const multiplied = Math.round(raw * p.nodeMultiplierBps / 10000 * p.eggMultiplierBps / 10000);
  return multiplied * months;
}
export function applyDiscount(subtotal: number, voucher?: {percentOff:number; fixedOff:number}) { if (!voucher) return 0; return Math.min(subtotal, Math.max(Math.floor(subtotal*voucher.percentOff/100), voucher.fixedOff)); }
