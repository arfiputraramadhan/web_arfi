import crypto from 'node:crypto';

// TOTP (RFC 6238) tanpa dependensi eksternal. SHA-1, 6 digit, periode 30 detik
// agar kompatibel dengan Google Authenticator, Authy, 1Password, dsb.
const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function base32Encode(buf: Buffer): string {
  let bits = 0, value = 0, out = '';
  for (const byte of buf) {
    value = ((value << 8) | byte) & 0xffff;
    bits += 8;
    while (bits >= 5) {
      out += ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
    value &= (1 << bits) - 1;
  }
  if (bits > 0) out += ALPHABET[(value << (5 - bits)) & 31];
  return out;
}

export function base32Decode(input: string): Buffer {
  const clean = input.replace(/=+$/, '').replace(/\s+/g, '').toUpperCase();
  let bits = 0, value = 0;
  const out: number[] = [];
  for (const ch of clean) {
    const idx = ALPHABET.indexOf(ch);
    if (idx < 0) throw new Error('INVALID_BASE32');
    value = ((value << 5) | idx) & 0xffff;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
    value &= (1 << bits) - 1;
  }
  return Buffer.from(out);
}

export function generateSecret(bytes = 20): string {
  return base32Encode(crypto.randomBytes(bytes));
}

export function hotp(secret: Buffer, counter: number, digits = 6): string {
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));
  const mac = crypto.createHmac('sha1', secret).update(msg).digest();
  const offset = mac[mac.length - 1] & 0x0f;
  const bin = ((mac[offset] & 0x7f) << 24) | (mac[offset + 1] << 16) | (mac[offset + 2] << 8) | mac[offset + 3];
  return String(bin % 10 ** digits).padStart(digits, '0');
}

export function totpAt(secretB32: string, timeMs = Date.now(), stepSec = 30, digits = 6): string {
  return hotp(base32Decode(secretB32), Math.floor(timeMs / 1000 / stepSec), digits);
}

/**
 * Mengembalikan nomor counter yang cocok (untuk pencegahan replay), atau null bila salah.
 * window=1 berarti toleransi 1 langkah (30 detik) sebelum/sesudah untuk selisih jam.
 */
export function verifyTotp(secretB32: string, token: string, opts: { window?: number; nowMs?: number; stepSec?: number } = {}): number | null {
  const { window = 1, nowMs = Date.now(), stepSec = 30 } = opts;
  if (!/^\d{6}$/.test(token)) return null;
  let secret: Buffer;
  try { secret = base32Decode(secretB32); } catch { return null; }
  const current = Math.floor(nowMs / 1000 / stepSec);
  const given = Buffer.from(token);
  for (let w = -window; w <= window; w++) {
    const counter = current + w;
    if (counter < 0) continue;
    const expected = Buffer.from(hotp(secret, counter));
    if (crypto.timingSafeEqual(expected, given)) return counter;
  }
  return null;
}

export function keyUri(account: string, issuer: string, secretB32: string): string {
  const label = `${encodeURIComponent(issuer)}:${encodeURIComponent(account)}`;
  return `otpauth://totp/${label}?secret=${secretB32}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
}
