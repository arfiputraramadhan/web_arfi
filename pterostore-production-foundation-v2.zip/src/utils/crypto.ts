import crypto from 'node:crypto';
import { env } from '../config/env.js';

export function randomToken(bytes = 32) { return crypto.randomBytes(bytes).toString('base64url'); }
export function sha256(value: string) { return crypto.createHash('sha256').update(value + env.CRYPTO_PEPPER).digest('hex'); }
export function hmacEqual(a: string, b: string) { const aa = Buffer.from(a); const bb = Buffer.from(b); return aa.length === bb.length && crypto.timingSafeEqual(aa, bb); }
function key() { return crypto.createHash('sha256').update(env.APP_ENCRYPTION_KEY).digest(); }
export function encrypt(plain: string) { const iv = crypto.randomBytes(12); const cipher = crypto.createCipheriv('aes-256-gcm', key(), iv); const enc = Buffer.concat([cipher.update(plain,'utf8'), cipher.final()]); return Buffer.concat([iv, cipher.getAuthTag(), enc]).toString('base64url'); }
export function decrypt(payload: string) { const raw = Buffer.from(payload,'base64url'); const iv = raw.subarray(0,12); const tag = raw.subarray(12,28); const data = raw.subarray(28); const decipher = crypto.createDecipheriv('aes-256-gcm', key(), iv); decipher.setAuthTag(tag); return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8'); }
export function normalizePhone(input: string) { const digits = input.replace(/\D/g,''); if (digits.startsWith('0')) return `62${digits.slice(1)}`; if (digits.startsWith('8')) return `62${digits}`; if (digits.startsWith('62')) return digits; throw new Error('INVALID_PHONE'); }
export function normalizeEmail(input: string) { return input.trim().toLowerCase(); }
