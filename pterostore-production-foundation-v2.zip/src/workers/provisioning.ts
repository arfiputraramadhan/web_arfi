import { Worker, Job } from 'bullmq';
import { redis } from '../lib/redis.js';
import { prisma } from '../lib/prisma.js';
import { pterodactyl } from '../modules/pterodactyl/service.js';
import { transitionOrder } from '../modules/orders/service.js';
import { randomToken, encrypt } from '../utils/crypto.js';
import { sendMail } from '../modules/notifications/service.js';
import { env } from '../config/env.js';

async function failProvisioning(job:Job, error:unknown){
  const orderId=String(job.data.orderId);
  try{
    await prisma.$transaction(async tx=>{
      const order=await tx.order.findUnique({where:{id:orderId},include:{user:true}});
      if(!order || order.status!=='PROVISIONING') return;
      await transitionOrder(tx,orderId,'FAILED',String(error instanceof Error?error.message:error).slice(0,500));
      const last=await tx.walletEntry.findFirst({where:{userId:order.userId},orderBy:{createdAt:'desc'}});
      const balance=(last?.balanceAfter??0)+order.amount;
      await tx.walletEntry.create({data:{userId:order.userId,type:'CREDIT',amount:order.amount,balanceAfter:balance,reason:'PROVISIONING_REFUND',referenceId:order.id}});
      await tx.notification.create({data:{userId:order.userId,channel:'DASHBOARD',title:'Provisioning gagal',body:`Order ${order.number} gagal dibuat. Dana Rp${order.amount.toLocaleString('id-ID')} dikembalikan ke saldo.`}});
    });
    if(env.ADMIN_ALERT_EMAIL) await sendMail(env.ADMIN_ALERT_EMAIL,`PteroStore provisioning FAILED: ${orderId}`,`<h1>Provisioning gagal</h1><p>Order ${orderId}</p><p>Worker: ${job.id}</p><p>Error: ${String(error)}</p>`);
  }catch(e){ console.error('provisioning_failure_handler_failed',e); }
}

export const provisioningWorker=new Worker('provisioning',async job=>{
 const order=await prisma.order.findUniqueOrThrow({where:{id:job.data.orderId},include:{user:true,items:{include:{product:{include:{egg:true}}}}}});
 if(order.status!=='PROVISIONING') return;
 const item=order.items[0]; const egg=item.product.egg;
 let pteroUser=order.user.pteroUserId?await pterodactyl.findUser(order.user.email):null;
 let panelPassword:string|undefined;
 if(!pteroUser){
   panelPassword=randomToken(12)+'A1!';
   pteroUser=await pterodactyl.createUser({email:order.user.email,username:order.user.username,password:panelPassword,first_name:order.user.username,last_name:'User'});
   await prisma.user.update({where:{id:order.userId},data:{pteroUserId:pteroUser.id,pteroPanelPasswordEnc:encrypt(panelPassword)}});
 }
 let node:any=null;
 if(item.nodeId){
   const dbNode=await prisma.node.findUnique({where:{id:item.nodeId}});
   if(dbNode){const nodes=await pterodactyl.listNodes();node=nodes.find((n:any)=>n.id===dbNode.pteroId);}
 } else {
   const nodes=await pterodactyl.listDeployableNodes(item.ramMb,item.diskGb*1024);
   node=nodes?.sort((a:any,b:any)=>(a.memory_overallocate??0)-(b.memory_overallocate??0))[0];
 }
 if(!node) throw new Error('NO_DEPLOYABLE_NODE');
 const allocations=await pterodactyl.listNodeAllocations(node.id);
 const alloc=allocations.find((a:any)=>!a.assigned);
 if(!alloc) throw new Error('NO_ALLOCATION');
 const server=await pterodactyl.createServer({external_id:order.id,name:`${order.user.username}-${order.number}`,description:'PteroStore managed server',user:pteroUser.id,egg:egg.pteroId,docker_image:egg.dockerImage||'ghcr.io/pterodactyl/yolks:java_21',startup:egg.startup||'bash',environment:{},limits:{memory:item.ramMb,swap:0,disk:item.diskGb*1024,cpu:item.cpuPercent,io:500,threads:null},feature_limits:{databases:0,allocations:1,backups:1},allocation:{default:alloc.id},start_on_completion:true});
 const expires=new Date(Date.now()+item.months*30*86400000);
 await prisma.server.create({data:{userId:order.userId,nodeId:(await prisma.node.findUnique({where:{pteroId:node.id}}))?.id,eggId:egg.id,orderId:order.id,pteroServerId:server.id,pteroIdentifier:server.identifier,name:server.name,ramMb:item.ramMb,cpuPercent:item.cpuPercent,diskGb:item.diskGb,expiresAt:expires,status:'ACTIVE'}});
 await prisma.$transaction(async tx=>{await transitionOrder(tx,order.id,'ACTIVE','PROVISIONING_OK');await tx.order.update({where:{id:order.id},data:{provisionedAt:new Date()}});});
 await sendMail(order.user.email,'Server aktif',`<h1>Server aktif</h1><p>Panel: ${env.PTERODACTYL_URL}</p><p>Username: ${order.user.username}</p>${panelPassword?`<p>Password panel: ${panelPassword}</p>`:''}<p>Server: ${server.identifier}</p>`);
},{connection:redis,concurrency:3});

provisioningWorker.on('failed',(job,error)=>{
  if(!job) return;
  const attempts=Number(job.opts.attempts??1);
  if(job.attemptsMade>=attempts) void failProvisioning(job,error);
});
