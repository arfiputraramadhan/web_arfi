import { Queue } from 'bullmq';
import { redis } from '../lib/redis.js';
export const provisioningQueue=new Queue('provisioning',{connection:redis});
export const notificationQueue=new Queue('notifications',{connection:redis});
export const reconciliationQueue=new Queue('reconciliation',{connection:redis});
export async function queueProvisioning(orderId:string){await provisioningQueue.add('provision',{orderId},{jobId:`provision:${orderId}`,attempts:5,backoff:{type:'exponential',delay:1500,jitter:0.25},removeOnComplete:1000,removeOnFail:5000});}
