import { Worker } from 'bullmq'; import { redis } from '../lib/redis.js';
export const notificationWorker=new Worker('notifications',async job=>{return {ok:true,type:job.name,data:job.data};},{connection:redis,concurrency:5});
