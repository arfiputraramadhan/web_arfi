import type { ErrorRequestHandler } from 'express';
import { ZodError } from 'zod';
import { HttpError } from '../utils/http.js';
import { logger } from '../lib/logger.js';
export const errorHandler: ErrorRequestHandler = (err, req, res, _next) => { logger.error({ err, path:req.path, method:req.method }, 'request_error'); if (err instanceof ZodError) return res.status(400).json({ok:false,error:'VALIDATION_ERROR',message:'Input tidak valid.'}); if (err instanceof HttpError) return res.status(err.status).json({ok:false,error:err.code,message:err.message}); return res.status(500).json({ok:false,error:'INTERNAL_ERROR',message:'Terjadi kesalahan internal.'}); };
