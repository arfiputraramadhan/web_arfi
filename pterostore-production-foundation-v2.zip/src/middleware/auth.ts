import type { RequestHandler } from 'express';
import { env } from '../config/env.js';
import { sha256 } from '../utils/crypto.js';
import { prisma } from '../lib/prisma.js';
import { redis } from '../lib/redis.js';

export const loadSession: RequestHandler = async (req,_res,next)=>{ try{ const raw=req.cookies?.[env.SESSION_COOKIE]; if(!raw) return next(); const hash=sha256(raw); const cached=await redis.get(`session:${hash}`); if(cached){ const s=JSON.parse(cached); (req as any).session=s; (req as any).user=s.user; return next(); } const s=await prisma.session.findUnique({where:{tokenHash:hash},include:{user:true}}); if(!s || s.status!=='ACTIVE' || s.expiresAt<new Date()) return next(); await redis.setex(`session:${hash}`, env.SESSION_TTL_SEC, JSON.stringify({id:s.id,user:s.user,csrfHash:s.csrfHash})); (req as any).session=s; (req as any).user=s.user; next(); }catch(e){next(e)} };
export const requireAuth: RequestHandler=(req,res,next)=>{ if(!(req as any).user) return res.status(401).json({ok:false,error:'UNAUTHENTICATED'}); next(); };
export function requireRole(...roles:string[]):RequestHandler{ return (req,res,next)=>{ const user=(req as any).user; if(!user || !roles.includes(user.role)) return res.status(403).json({ok:false,error:'FORBIDDEN'}); next(); }; }
