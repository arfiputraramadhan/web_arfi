import type { RequestHandler } from 'express';
import { RateLimiterRedis } from 'rate-limiter-flexible';
import { redis } from '../lib/redis.js';
export function rateLimit(keyPrefix:string, points:number, duration:number):RequestHandler { const limiter = new RateLimiterRedis({storeClient:redis, keyPrefix, points, duration}); return async (req,res,next)=>{ const key=`${req.ip}:${String(req.body?.email||req.body?.username||req.body?.phone||'')}`; try{await limiter.consume(key); next();}catch{res.status(429).json({ok:false,error:'RATE_LIMITED',message:'Terlalu banyak percobaan. Silakan coba lagi nanti.'});} }; }
