# Catatan Perbaikan (v2)

Perbaikan atas hasil review v1. Semua bug kritis di bawah sudah ditangani di kode; yang tercantum di "Masih terbuka" belum disentuh.

## Diperbaiki

1. **Pencetak saldo lewat upgrade server.** `RAM` negatif membuat selisih harga negatif sehingga saldo dikredit.
   - Input kini divalidasi ketat (`src/modules/servers/spec.ts`): hanya bilangan bulat dalam rentang RAM 512-32768 MB, CPU 10-800%, disk 1-500 GB. Sesuaikan `SPEC_LIMITS` dengan kapasitas node Anda.
   - Urutan transaksi diubah: debit (bila naik) -> ubah di Pterodactyl -> bila gagal, debit dikembalikan; kredit downgrade baru diberikan setelah Pterodactyl berhasil. Saldo tidak bisa negatif dan dikunci per user.
   - Upgrade hanya untuk server ACTIVE yang belum kedaluwarsa. Perbaikan tambahan: `allocation` untuk build update kini diambil dengan benar.
2. **User bisa mengaktifkan server kedaluwarsa tanpa bayar.** Endpoint `/api/servers/:id/suspend` dan `/unsuspend` milik user dihapus. Versi admin tersedia di `/api/admin/servers/:id/suspend|unsuspend` (OWNER/ADMIN, tercatat di audit log; unsuspend ditolak bila masa aktif sudah lewat).
3. **2FA tidak pernah dicek saat login.** Login kini 2 langkah: bila `totpEnabled`, server membalas `TOTP_REQUIRED` dan sesi baru dibuat setelah kode valid. Pengaman: maksimal 5 kode salah per 5 menit, kode tidak bisa dipakai ulang (anti replay), `setup` ditolak bila 2FA sudah aktif, dan `disable` wajib kode 2FA saat ini. TOTP diimplementasi sendiri (`src/utils/totp.ts`, RFC 6238, diuji dengan vektor resmi) sehingga dependensi `otplib` dihapus.
4. **Aplikasi gagal start / flag salah dengan `.env.example`.** `z.coerce.boolean()` menganggap `"false"` sebagai `true`. Diganti `envBool()` (`src/config/envHelpers.ts`). Variabel kosong (mis. `ADMIN_DISCORD_WEBHOOK_URL=`) kini dianggap tidak diisi.
5. **Test.** Harga di test diperbaiki (18500), dan semua test kini mengimpor kode asli (transisi order, verifikasi webhook, TOTP, validasi spesifikasi, parser boolean). Termasuk test regresi untuk eksploit RAM negatif.

## Perbaikan turunan

- Harga perpanjang, upgrade, dan auto-renew kini dihitung dari data produk yang dibeli (tarif RAM/CPU/disk + pengali node/egg), bukan rumus hardcode. Perpanjang ditolak untuk server DELETED, dan panggilan Pterodactyl di dalam transaksi diberi timeout 20 detik.
- Cron auto-renew memakai fungsi yang sama dengan tombol perpanjang; error satu server tidak menghentikan server lain.
- Halaman `account`, `reset`, `tickets`, `wallet` memakai `<script>` inline yang diblokir CSP (`script-src 'self'`) sehingga tidak berfungsi, termasuk halaman reset password. Skrip dipindah ke `public/assets/pages/*.js`.
- Halaman login menampilkan kolom kode 2FA saat diminta; halaman akun bisa menonaktifkan 2FA.

## Masih terbuka (belum disentuh)

- Kode belum dijalankan end-to-end: `npm install`, `prisma migrate`, `tsc` penuh, dan vitest penuh belum bisa dijalankan di lingkungan pembuatan. Jalankan `npm install && npm run lint && npm test` lebih dulu.
- Katalog Pterodactyl memanggil `/api/application/tags` dan `/eggs`; Pterodactyl 1.x memakai `nests` dan `/nests/{id}/eggs`. Sesuaikan dengan versi panel Anda.
- Pembuatan server mengirim `environment: {}`; egg dengan variabel wajib kemungkinan gagal (isi dari variabel default egg).
- OTP memakai `Math.random()` (ganti `crypto.randomInt`); register membocorkan akun yang sudah ada; rate limit login hanya per IP dan belum ada lockout akun.
- CSRF masih menerima token dari cookie sebagai cadangan; CSP memblokir atribut `style=""` inline (sekitar 10 tempat).
- Voucher tetap hangus saat order batal/kedaluwarsa; rekonsiliasi cron berhenti bila satu item error dan top up belum direkonsiliasi; retry provisioning bisa membuat server ganda.
- Simulasi sandbox masih memakai endpoint Pakasir v1 (dimatikan 20 Okt 2026).
