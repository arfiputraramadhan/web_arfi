# Architecture Notes

## Layering

`route -> controller -> service -> repository/data access`

Untuk menjaga ukuran implementasi tetap ringan, Prisma access layer berada langsung di service untuk modul kecil. Modul integrasi vendor dipisahkan (`payments/pakasir`, `pterodactyl`).

## State consistency

Order state dibatasi oleh adjacency map dan `stateVersion`. Update menggunakan `updateMany` dengan pasangan `(id,status,stateVersion)`, sehingga dua webhook/provision job yang datang bersamaan tidak dapat menggandakan transisi.

Wallet memakai row lock PostgreSQL pada `User` sebelum menghitung saldo terbaru.

## Secrets

Tidak ada API key pembayaran/Pterodactyl/SMTP yang dikirim ke browser. Pterodactyl Client API key user dienkripsi AES-256-GCM sebelum disimpan.

## Queue separation

- `provisioning`: create user/server, retry exponential.
- `notifications`: tersedia sebagai queue untuk workload notifikasi.
- `reconciliation`: namespace untuk rekonsiliasi tambahan.

## Vendor boundary

Semua request vendor dibuat melalui service sehingga timeout/error/circuit-breaker bisa ditambahkan tanpa menyentuh controller.
