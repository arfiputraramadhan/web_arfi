# Security Verification Checklist

## Authentication

- [ ] Register dengan disposable email harus ditolak.
- [ ] OTP salah 5x harus terkunci.
- [ ] OTP expired harus ditolak.
- [ ] Reset link expired/used harus ditolak.
- [ ] Password lama dan semua session dicabut setelah reset.
- [ ] Login gagal selalu menggunakan pesan generik.

## Session / CSRF

- [ ] Session cookie `httpOnly`.
- [ ] Secure aktif di production.
- [ ] CSRF header wajib untuk method mutating.
- [ ] Logout-all mencabut semua session.
- [ ] Session revoked tidak dapat dipakai lagi.

## Authorization

- [ ] User A tidak dapat membaca order/server/wallet user B.
- [ ] Admin MFA aktif sebelum akses admin.
- [ ] STAFF tidak bisa mengubah produk/voucher/node unless role diizinkan route.

## Payment

- [ ] Webhook path secret harus salah jika URL dimodifikasi.
- [ ] X-Secret Pakasir harus match constant-time.
- [ ] order_id + amount wajib match database.
- [ ] status Pakasir di-recheck dari server-to-server.
- [ ] webhook duplicate tidak membuat server kedua.
- [ ] PENDING expired dibatalkan cron.

## Wallet / race condition

- [ ] Debit saldo memakai `FOR UPDATE`.
- [ ] Top-up credit conditional PENDING->PAID.
- [ ] Referral bonus memiliki uniqueness guard.

## Pterodactyl

- [ ] Application API key tidak pernah di frontend/log.
- [ ] Client API key terenkripsi at-rest.
- [ ] Server user action melakukan ownership check.
- [ ] Backup download URL diteruskan tanpa mengekspos Client API key.

## Transport / HTTP

- [ ] HTTPS di reverse proxy.
- [ ] HSTS production.
- [ ] CSP aktif.
- [ ] CORS exact origin.
- [ ] Request size limit diuji.

## OWASP quick pass

- A01 Broken Access Control — ownership + role checks.
- A02 Cryptographic Failures — Argon2id + AES-256-GCM + secret env.
- A03 Injection — Prisma parameterization + Zod.
- A04 Insecure Design — state machine + idempotence + row lock.
- A05 Security Misconfiguration — Helmet/CSP/body limits/env validation.
- A06 Vulnerable Components — CI npm audit.
- A07 Identification/Auth — OTP, reset token, session revoke, MFA.
- A08 Software/Data Integrity — locked payment transitions + queue jobs.
- A09 Logging/Monitoring — Pino + audit/security models.
- A10 SSRF — outgoing integrations are fixed vendor base URLs from env.
