import { describe, it, expect } from 'vitest';
import { pstr } from '../src/utils/http.js';

describe('pstr (param Express 5)', () => {
  it('mengembalikan string untuk string, array, dan nilai kosong', () => {
    expect(pstr('abc')).toBe('abc');
    expect(pstr(['x', 'y'])).toBe('x');
    expect(pstr(undefined)).toBe('');
    expect(pstr(null)).toBe('');
    expect(pstr(42)).toBe('42');
  });
});
