export class HttpError extends Error { constructor(public status:number, message:string, public code='BAD_REQUEST') { super(message); } }
export async function fetchJson<T>(url:string, init:RequestInit = {}, timeoutMs=10000):Promise<T>{ const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(), timeoutMs); try { const res=await fetch(url,{...init,signal:controller.signal,headers:{accept:'application/json',...(init.headers||{})}}); const text=await res.text(); const body=text?JSON.parse(text):{}; if(!res.ok) throw new HttpError(res.status, `Upstream HTTP ${res.status}`, 'UPSTREAM_ERROR'); return body as T; } finally { clearTimeout(timer); } }

/** Express 5 mengetik req.params sebagai string | string[]. Helper ini selalu mengembalikan string. */
export function pstr(v: unknown): string { const x = Array.isArray(v) ? v[0] : v; return typeof x === 'string' ? x : String(x ?? ''); }
