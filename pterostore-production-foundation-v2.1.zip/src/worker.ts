import './workers/provisioning.js';import './workers/notifications.js';import {startCron} from './cron/scheduler.js';
startCron();console.log('PteroStore workers started');
