import {pstr} from '../../utils/http.js';
import {Router} from 'express';import {prisma} from '../../lib/prisma.js';const r=Router();r.get('/:slug',async(req,res)=>{const p=await prisma.contentPage.findFirst({where:{slug:pstr(req.params.slug),locale:String(req.query.locale||'id')}});if(!p)return res.status(404).json({ok:false,error:'NOT_FOUND'});res.json({ok:true,page:p})});export default r;
